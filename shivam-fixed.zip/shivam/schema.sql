-- ====================================================================
-- ExamDuniya - Government Exam Notifications & AI Mock Tests
-- MySQL Database Schema / SQL Dump File
-- ====================================================================
--
-- Bhai, ye SQL schema file hai jise aap seedhe phpMyAdmin ya kisi bhi
-- MySQL console se import kar sakte hain.
--
-- Note: Agar aapne environment variables (.env) configure kiye hain:
-- DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, DB_PORT
-- Toh humara server application startup par ye saari tables automatically
-- create kar leta hai. Lekin agar aap manually cPanel phpMyAdmin, 
-- RDS, ya external Cloud SQL par install karna chahte hain toh is file ka 
-- use karein.
--
-- ====================================================================

-- Create Database (Optional, uncomment if installing on clean MySQL instance)
-- CREATE DATABASE IF NOT EXISTS examduniya;
-- USE examduniya;

SET FOREIGN_KEY_CHECKS = 0;

-- --------------------------------------------------------------------
-- 1. Table structure for table `users`
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `email` VARCHAR(150) UNIQUE NOT NULL,
  `name` VARCHAR(100) DEFAULT NULL,
  `role` VARCHAR(50) DEFAULT 'user', -- 'user', 'admin', 'developer'
  `isVerified` BOOLEAN DEFAULT FALSE,
  `passwordHash` VARCHAR(256) NOT NULL,
  `savedNotifications` TEXT DEFAULT NULL, -- JSON formatted array of saved job IDs
  `bookmarks` TEXT DEFAULT NULL,          -- JSON formatted array of bookmarked mock tests
  `createdAt` VARCHAR(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 2. Table structure for table `jobs`
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `department` TEXT DEFAULT NULL,
  `category` VARCHAR(100) DEFAULT NULL, -- e.g., 'SSC', 'Railways', 'UP Police', 'UPSC'
  `postCount` INT DEFAULT 0,
  `publishDate` VARCHAR(100) DEFAULT NULL,
  `lastDateToApply` VARCHAR(100) DEFAULT NULL,
  `examDate` VARCHAR(100) DEFAULT NULL,
  `pdfUrl` TEXT DEFAULT NULL,
  `applyUrl` TEXT DEFAULT NULL,
  `officialWebsite` TEXT DEFAULT NULL,
  `ageLimit` TEXT DEFAULT NULL,
  `qualification` TEXT DEFAULT NULL,
  `applicationFee` TEXT DEFAULT NULL,
  `details` TEXT DEFAULT NULL -- Detailed markdown guidelines for the notification
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 3. Table structure for table `admit_cards`
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admit_cards` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) DEFAULT NULL,
  `examDate` VARCHAR(100) DEFAULT NULL,
  `downloadUrl` TEXT DEFAULT NULL,
  `status` VARCHAR(100) DEFAULT 'Active', -- 'Active', 'Exam Postponed', 'Released'
  `releaseDate` VARCHAR(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 4. Table structure for table `results`
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `results` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) DEFAULT NULL,
  `declareDate` VARCHAR(100) DEFAULT NULL,
  `resultUrl` TEXT DEFAULT NULL,
  `status` VARCHAR(100) DEFAULT 'Declared' -- 'Declared', 'Awaiting'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 5. Table structure for table `answer_keys`
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `answer_keys` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) DEFAULT NULL,
  `keyReleaseDate` VARCHAR(100) DEFAULT NULL,
  `answerKeyUrl` TEXT DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 6. Table structure for table `current_affairs`
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `current_affairs` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `content` TEXT DEFAULT NULL,
  `date` VARCHAR(100) DEFAULT NULL,
  `category` VARCHAR(100) DEFAULT NULL, -- e.g., 'National', 'Science & Tech', 'Sports'
  `tags` TEXT DEFAULT NULL -- Comma-separated or JSON array of tags
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 7. Table structure for table `mock_tests`
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `mock_tests` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) DEFAULT NULL, -- e.g., 'SSC CGL', 'UP Police', 'Railway NTPC'
  `durationMinutes` INT DEFAULT 60,
  `totalQuestions` INT DEFAULT 100,
  `isPaid` BOOLEAN DEFAULT FALSE,
  `scoreWeight` FLOAT DEFAULT 2.0, -- Points per correct answer
  `negativeMarks` FLOAT DEFAULT 0.5, -- Negative points per wrong answer
  `questions` TEXT DEFAULT NULL, -- JSON structure of array of QA questions
  `createdAt` VARCHAR(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 8. Table structure for table `attempts`
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `attempts` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `userId` VARCHAR(100) NOT NULL,
  `mockTestId` VARCHAR(100) NOT NULL,
  `mockTestTitle` VARCHAR(255) NOT NULL,
  `score` FLOAT DEFAULT 0.0,
  `totalQuestions` INT DEFAULT 0,
  `correctAnswersCount` INT DEFAULT 0,
  `wrongAnswersCount` INT DEFAULT 0,
  `unattemptedCount` INT DEFAULT 0,
  `durationSpentSeconds` INT DEFAULT 0,
  `percentile` FLOAT DEFAULT 0.0,
  `rank` INT DEFAULT 1,
  `totalParticipants` INT DEFAULT 1,
  `subjectAnalysis` TEXT DEFAULT NULL, -- JSON object analyze subtopic metrics
  `createdAt` VARCHAR(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 9. Table structure for table `subscriptions`
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `userId` VARCHAR(100) NOT NULL,
  `packId` VARCHAR(100) NOT NULL, -- e.g. 'pack-pro-monthly', 'pack-master-annual'
  `packName` VARCHAR(255) NOT NULL,
  `purchaseDate` VARCHAR(100) DEFAULT NULL,
  `expiryDate` VARCHAR(100) DEFAULT NULL,
  `amount` FLOAT DEFAULT 0.0,
  `status` VARCHAR(50) DEFAULT 'active' -- 'active', 'expired'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 10. Table structure for table `payments`
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `payments` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `userId` VARCHAR(100) NOT NULL,
  `userEmail` VARCHAR(150) NOT NULL,
  `packId` VARCHAR(100) NOT NULL,
  `packName` VARCHAR(255) NOT NULL,
  `amount` FLOAT DEFAULT 0.0,
  `status` VARCHAR(50) DEFAULT 'pending', -- 'pending', 'success', 'failed'
  `createdAt` VARCHAR(100) DEFAULT NULL,
  `transactionId` VARCHAR(100) DEFAULT NULL,
  `gstInvoiceNo` VARCHAR(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 11. Table structure for table `settings`
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `settings` (
  `id` VARCHAR(20) NOT NULL PRIMARY KEY,
  `geminiModel` VARCHAR(100) DEFAULT 'gemini-3.5-flash',
  `googleOAuthEnabled` BOOLEAN DEFAULT TRUE,
  `payUEnabled` BOOLEAN DEFAULT TRUE,
  `maintenanceMode` BOOLEAN DEFAULT FALSE,
  `smtpStatus` VARCHAR(100) DEFAULT 'Configured'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 12. Table structure for table `logs`
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `logs` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `timestamp` VARCHAR(100) DEFAULT NULL,
  `type` VARCHAR(50) DEFAULT 'info', -- 'info', 'warning', 'error', 'security'
  `message` TEXT DEFAULT NULL,
  `meta` TEXT DEFAULT NULL -- Extra JSON meta metrics logging data
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed default settings config
INSERT INTO `settings` (`id`, `geminiModel`, `googleOAuthEnabled`, `payUEnabled`, `maintenanceMode`, `smtpStatus`)
VALUES ('default', 'gemini-3.5-flash', 1, 1, 0, 'Configured')
ON DUPLICATE KEY UPDATE `id`=`id`;

SET FOREIGN_KEY_CHECKS = 1;
