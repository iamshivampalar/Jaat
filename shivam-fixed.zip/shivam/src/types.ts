export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'user' | 'developer';
  isVerified: boolean;
  avatar?: string;
  savedNotifications: string[]; // jobIds
  bookmarks: string[]; // mockTestIds
  createdAt: string;
}

export interface JobNotification {
  id: string;
  title: string;
  department: string;
  category: string; // SSC, UPSC, Bank, Railway, UP Police, etc.
  postCount: number;
  publishDate: string;
  lastDateToApply: string;
  examDate?: string;
  pdfUrl: string;
  applyUrl: string;
  officialWebsite: string;
  details: string; // HTML or Markdown structured text
  ageLimit: string;
  qualification: string;
  applicationFee: string;
}

export interface AdmitCard {
  id: string;
  title: string;
  category: string;
  examDate: string;
  downloadUrl: string;
  status: 'Released' | 'Expected Soon';
  releaseDate: string;
}

export interface Result {
  id: string;
  title: string;
  category: string;
  declareDate: string;
  resultUrl: string;
  status: 'Released' | 'Awaiting';
}

export interface AnswerKey {
  id: string;
  title: string;
  category: string;
  keyReleaseDate: string;
  answerKeyUrl: string;
}

export interface CurrentAffairs {
  id: string;
  title: string;
  content: string;
  date: string;
  category: string; // National, International, Economy, Sports, Science
  tags: string[];
}

export interface Question {
  id: string;
  text: string;
  options: string[];
  answerIndex: number; // 0, 1, 2, 3
  explanation: string;
  subject: string;
  topic?: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

export interface MockTest {
  id: string;
  title: string;
  category: string; // SSC CGL, RRB NTPC, UP Police Constable, etc.
  durationMinutes: number;
  totalQuestions: number;
  isPaid: boolean;
  scoreWeight: number; // e.g. 2 marks per question
  negativeMarks: number; // e.g. 0.5 negative marking
  questions: Question[];
  createdAt: string;
}

export interface MockTestAttempt {
  id: string;
  userId: string;
  mockTestId: string;
  mockTestTitle: string;
  score: number;
  totalQuestions: number;
  correctAnswersCount: number;
  wrongAnswersCount: number;
  unattemptedCount: number;
  durationSpentSeconds: number;
  percentile: number;
  rank: number;
  totalParticipants: number;
  subjectAnalysis: {
    subject: string;
    total: number;
    correct: number;
    wrong: number;
  }[];
  createdAt: string;
}

export interface Subscription {
  id: string;
  userId: string;
  packId: string;
  packName: string;
  purchaseDate: string;
  expiryDate: string;
  amount: number;
  status: 'active' | 'expired';
}

export interface PaymentTransaction {
  id: string;
  userId: string;
  userEmail: string;
  packId: string;
  packName: string;
  amount: number;
  status: 'Success' | 'Failed' | 'Pending';
  createdAt: string;
  transactionId: string;
  gstInvoiceNo: string;
}

export interface LeaderboardUser {
  userId: string;
  name: string;
  testsAttempted: number;
  averageScore: number;
  totalPoints: number;
  rank: number;
}

export interface SystemLog {
  id: string;
  timestamp: string;
  type: 'info' | 'error' | 'api' | 'auth';
  message: string;
  meta?: any;
}

export interface SystemSettings {
  geminiModel: string;
  googleOAuthEnabled: boolean;
  payUEnabled: boolean;
  maintenanceMode: boolean;
  smtpStatus: 'Configured' | 'Not Configured';
  telegramStatus?: 'Configured' | 'Not Configured';
}
