import { useEffect } from 'react';
import { JobNotification } from '../types';

interface SEOProps {
  currentTab: 'home' | 'jobs' | 'mocktests' | 'currentaffairs' | 'subscription' | 'profile' | 'admin' | 'developer';
  selectedJob: JobNotification | null;
}

export function SEO({ currentTab, selectedJob }: SEOProps) {
  useEffect(() => {
    let title = 'ExamDuniya - Government Exam Notifications, Alerts & AI Mock Tests';
    let description = 'India\'s Smartest Government Exam Notification, Alerts, and AI Mock Test Platform. Stay updated with Sarkari job alerts, admit cards, and results.';
    let ogTitle = title;
    let ogDescription = description;
    let ogImage = 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=1200&q=80';
    let canonicalUrl = window.location.origin;
    let robotsValue = 'index, follow';

    // 1. Determine metadata, canonical URL, and robots crawler directives based on active viewing state
    if (selectedJob) {
      const slug = (selectedJob.title || '')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
      title = `${selectedJob.title} - ${selectedJob.category} Recruitment Alert | ExamDuniya`;
      description = `Official Recruitment Notification for ${selectedJob.postCount} vacancies in ${selectedJob.department}. Last date to apply: ${selectedJob.lastDateToApply}. Qualification: ${selectedJob.qualification}. Check details, PDF and apply online on ExamDuniya.`;
      ogTitle = selectedJob.title;
      ogDescription = `Check educational qualifications, age limit, selection process, and application steps for ${selectedJob.postCount} posts in ${selectedJob.category}.`;
      canonicalUrl = `${window.location.origin}/jobs/${selectedJob.id}/${slug}`;
      robotsValue = 'index, follow, max-image-preview:large';
    } else {
      switch (currentTab) {
        case 'home':
          title = 'ExamDuniya - Home | Smartest Sarkari Job Alerts & AI Mock Tests';
          description = 'Get instant verified central & state government exam notifications, results, admit cards, current affairs, and practice personalized AI-generated Mock Tests.';
          canonicalUrl = `${window.location.origin}/`;
          robotsValue = 'index, follow';
          break;
        case 'jobs':
          title = 'Sarkari Job Notifications & Live Recruitment Alerts | ExamDuniya';
          description = 'Browse latest government job recruitments instantly filtered by SSC, Railways, Bank, Defense, and State levels. Free notifications with downloadable PDFs.';
          canonicalUrl = `${window.location.origin}/jobs`;
          robotsValue = 'index, follow';
          break;
        case 'mocktests':
          title = 'AI-Customized Live SSC & State Police Mock Tests | ExamDuniya';
          description = 'Practice highly tailored digital mock tests with real-time negative scoring, subtopic feedback, percentiles and instant leaderboard rankings.';
          canonicalUrl = `${window.location.origin}/mocktests`;
          robotsValue = 'index, follow';
          break;
        case 'currentaffairs':
          title = 'Daily Live Current Affairs & General Knowledge Review | ExamDuniya';
          description = 'Enhance your GS & GA preparation with daily comprehensive national, international, science, and economy dynamic trivia capsules.';
          canonicalUrl = `${window.location.origin}/currentaffairs`;
          robotsValue = 'index, follow';
          break;
        case 'subscription':
          title = 'Premium Subscription Plans - Unlimited Practice Series | ExamDuniya';
          description = 'Unlock VIP access to all premium curated multi-series mock databases, complete historical metrics, and live leaderboards.';
          canonicalUrl = `${window.location.origin}/subscription`;
          robotsValue = 'index, follow';
          break;
        case 'profile':
          title = 'Aspirant Performance Workspace & Resume Center | ExamDuniya';
          description = 'View your active test analytics, personalized score cards, percentile tracks, and saved jobs.';
          canonicalUrl = `${window.location.origin}/profile`;
          robotsValue = 'noindex, nofollow'; // Do not index candidate portfolio dashboards
          break;
        case 'admin':
          title = 'Central Administrative Management Console | ExamDuniya';
          description = 'Configure live Sarkari feeds, manage subscriber catalogs, and audit database transaction pipelines.';
          canonicalUrl = `${window.location.origin}/admin`;
          robotsValue = 'noindex, nofollow'; // Do not leak admin controls to indexers
          break;
        case 'developer':
          title = 'Core Developer Sandbox Node Workspace | ExamDuniya';
          description = 'Interact with Gemini LLM models for auto-generating mocks, monitoring API telemetry, and auditing server memory datasets.';
          canonicalUrl = `${window.location.origin}/developer`;
          robotsValue = 'noindex, nofollow'; // Do not expose development sandbox endpoints to search crawl engines
          break;
      }
      ogTitle = title;
      ogDescription = description;
    }

    // 2. Direct DOM injection
    document.title = title;

    const updateCanonicalLink = (href: string) => {
      let link: HTMLLinkElement | null = document.querySelector('link[rel="canonical"]');
      if (!link) {
        link = document.createElement('link');
        link.setAttribute('rel', 'canonical');
        document.head.appendChild(link);
      }
      link.setAttribute('href', href);
    };

    const updateMetaTag = (selector: string, attribute: string, value: string) => {
      let element = document.querySelector(selector);
      if (!element) {
        element = document.createElement('meta');
        if (selector.startsWith('meta[property=')) {
          const propName = selector.slice(15, -2);
          element.setAttribute('property', propName);
        } else if (selector.startsWith('meta[name=')) {
          const nameValue = selector.slice(11, -2);
          element.setAttribute('name', nameValue);
        }
        document.head.appendChild(element);
      }
      element.setAttribute(attribute, value);
    };

    // Description Meta
    updateMetaTag('meta[name="description"]', 'content', description);

    // Canonical link
    updateCanonicalLink(canonicalUrl);

    // Robots directive
    updateMetaTag('meta[name="robots"]', 'content', robotsValue);

    // Open Graph Tags
    updateMetaTag('meta[property="og:title"]', 'content', ogTitle);
    updateMetaTag('meta[property="og:description"]', 'content', ogDescription);
    updateMetaTag('meta[property="og:image"]', 'content', ogImage);

    // Twitter Tags
    updateMetaTag('meta[name="twitter:title"]', 'content', ogTitle);
    updateMetaTag('meta[name="twitter:description"]', 'content', ogDescription);

  }, [currentTab, selectedJob]);

  return null; // Side effect component that renders nothing visible
}
