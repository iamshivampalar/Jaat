import React, { useState, useEffect } from 'react';
import { 
  Bell, FileText, Award, Calendar, AlertCircle, BookOpen, Compass, 
  Crown, Settings, Terminal, Shield, LogIn, LogOut, CheckCircle2, 
  ChevronRight, X, Play, RefreshCw, Bookmark, Search, Clock, Send,
  FileSpreadsheet, Filter, Check, Star, Lock, User as UserIcon, Trash2, Cpu, Menu
} from 'lucide-react';
import { 
  User, JobNotification, AdmitCard, Result, AnswerKey, 
  CurrentAffairs, MockTest, MockTestAttempt, Subscription, 
  PaymentTransaction, LeaderboardUser, SystemLog, SystemSettings, Question 
} from './types';
import { SEO } from './components/SEO';

export default function App() {
  // Navigation & Authentication
  const [currentTab, setCurrentTab] = useState<'home' | 'jobs' | 'mocktests' | 'currentaffairs' | 'subscription' | 'profile' | 'admin' | 'developer'>('home');
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('examduniya_token'));
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Auth Form State
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authName, setAuthName] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [authError, setAuthError] = useState('');
  const [showAuthModal, setShowAuthModal] = useState(false);

  // Forgot Password Flow States
  const [forgotStep, setForgotStep] = useState<'request' | 'reset' | null>(null);
  const [forgotCode, setForgotCode] = useState('');
  const [forgotNewPassword, setForgotNewPassword] = useState('');
  const [forgotSuccessMessage, setForgotSuccessMessage] = useState('');
  const [showSecretBypass, setShowSecretBypass] = useState(false);


  // Content Feeds
  const [jobs, setJobs] = useState<JobNotification[]>([]);
  const [admitCards, setAdmitCards] = useState<AdmitCard[]>([]);
  const [results, setResults] = useState<Result[]>([]);
  const [answerKeys, setAnswerKeys] = useState<AnswerKey[]>([]);
  const [currentAffairs, setCurrentAffairs] = useState<CurrentAffairs[]>([]);
  const [mockTests, setMockTests] = useState<MockTest[]>([]);
  const [attempts, setAttempts] = useState<MockTestAttempt[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderboardUser[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [paymentHistory, setPaymentHistory] = useState<PaymentTransaction[]>([]);
  
  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedJob, setSelectedJob] = useState<JobNotification | null>(null);

  // Exam Simulator State
  const [activeTest, setActiveTest] = useState<MockTest | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<{ [qId: string]: number }>({});
  const [reviewStatus, setReviewStatus] = useState<{ [qId: string]: boolean }>({});
  const [examTimeLeft, setExamTimeLeft] = useState(0);
  const [isExamActive, setIsExamActive] = useState(false);
  const [examResult, setExamResult] = useState<{ attempt: MockTestAttempt; solutions: any[] } | null>(null);

  // AI Generation State
  const [aiExamName, setAiExamName] = useState('SSC');
  const [aiSubject, setAiSubject] = useState('General Knowledge');
  const [aiTopic, setAiTopic] = useState('Ancient Indian History');
  const [aiDifficulty, setAiDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>('Medium');
  const [aiQuantity, setAiQuantity] = useState(5);
  const [aiGenerating, setAiGenerating] = useState(false);
  const [aiSuccessMessage, setAiSuccessMessage] = useState('');

  const [aiCaTopic, setAiCaTopic] = useState('ISRO Mars Mission Orbit 2026');
  const [aiCaCategory, setAiCaCategory] = useState('Science & Technology');
  const [aiCaGenerating, setAiCaGenerating] = useState(false);

  // Controls Management State
  const [systemLogs, setSystemLogs] = useState<SystemLog[]>([]);
  const [systemSettings, setSystemSettings] = useState<SystemSettings | null>(null);

  // New Alert Creation State for Admin Tab
  const [newJobType, setNewJobType] = useState({
    title: '', department: '', category: 'SSC', postCount: 150, 
    lastDateToApply: '2026-07-31', examDate: '2026-09-10', pdfUrl: '#',
    applyUrl: '#', officialWebsite: '#', details: '', ageLimit: '18-27 Years',
    qualification: 'Graduation in any stream', applicationFee: '₹100'
  });

  // Dynamic status messages
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Automatically fetch content on load & when auth state changes
  useEffect(() => {
    fetchPublicData();
    if (token) {
      fetchUserProfile();
    }
  }, [token]);

  // Restore saved mock test progress on user session activation
  useEffect(() => {
    if (user) {
      const saved = localStorage.getItem(`examduniya_progress_${user.id}`);
      if (saved) {
        try {
          const data = JSON.parse(saved);
          if (data.activeTest && typeof data.examTimeLeft === 'number' && data.examTimeLeft > 0) {
            setActiveTest(data.activeTest);
            setCurrentQuestionIndex(data.currentQuestionIndex || 0);
            setAnswers(data.answers || {});
            setReviewStatus(data.reviewStatus || {});
            setExamTimeLeft(data.examTimeLeft);
            setIsExamActive(true);
            setExamResult(null);
            
            triggerToast(`🔄 Resumed your active mock test session: "${data.activeTest.title}"`);
          } else {
            localStorage.removeItem(`examduniya_progress_${user.id}`);
          }
        } catch (err) {
          console.error("Error restoring saved progress", err);
        }
      }
    }
  }, [user]);

  // Save mock test progress to localStorage
  useEffect(() => {
    if (user && isExamActive && activeTest) {
      const progressData = {
        activeTest,
        currentQuestionIndex,
        answers,
        reviewStatus,
        examTimeLeft
      };
      localStorage.setItem(`examduniya_progress_${user.id}`, JSON.stringify(progressData));
    }
  }, [user, isExamActive, activeTest, currentQuestionIndex, answers, reviewStatus, examTimeLeft]);

  // Intercept real PayU transaction callbacks on App Mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const paymentStatus = params.get('payment');
    if (paymentStatus === 'success') {
      triggerToast(`🎉 Real PayU Payment Verified! Premium Pack unlocked successfully.`);
      // Clear URL search queries for clean visual aesthetics
      window.history.replaceState({}, document.title, window.location.pathname);
      fetchUserProfile();
      setCurrentTab('profile');
    } else if (paymentStatus === 'failed') {
      const reason = params.get('reason') || 'Transaction Cancelled';
      triggerToast(`⚠️ Gateway Response: ${reason}. Please retry.`);
      window.history.replaceState({}, document.title, window.location.pathname);
      setCurrentTab('subscription');
    }
  }, []);

  // Google sign in popup message listener
  useEffect(() => {
    const handleGoogleMessage = (event: MessageEvent) => {
      const origin = event.origin;
      if (!origin.endsWith('.run.app') && !origin.includes('localhost')) {
        return;
      }
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS') {
        const { token: oAuthToken, user: oAuthUser } = event.data;
        if (oAuthToken && oAuthUser) {
          localStorage.setItem('examduniya_token', oAuthToken);
          setToken(oAuthToken);
          setUser(oAuthUser);
          setShowAuthModal(false);
          setForgotStep(null); // Clear any forgot passwords flow
          setAuthError('');
          triggerToast(`Welcome back, ${oAuthUser.name}! Google sign-in successful.`);
        }
      }
    };
    window.addEventListener('message', handleGoogleMessage);
    return () => window.removeEventListener('message', handleGoogleMessage);
  }, []);

  // Exam timer clock effect
  useEffect(() => {
    if (isExamActive && examTimeLeft > 0) {
      const timer = setInterval(() => {
        setExamTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(timer);
            submitExam(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isExamActive, examTimeLeft]);

  const fetchPublicData = async () => {
    try {
      const jRes = await fetch('/api/jobs');
      const jData = await jRes.json();
      setJobs(jData);

      const aRes = await fetch('/api/admit-cards');
      const aData = await aRes.json();
      setAdmitCards(aData);

      const rRes = await fetch('/api/results');
      const rData = await rRes.json();
      setResults(rData);

      const akRes = await fetch('/api/answer-keys');
      const akData = await akRes.json();
      setAnswerKeys(akData);

      const caRes = await fetch('/api/current-affairs');
      const caData = await caRes.json();
      setCurrentAffairs(caData);

      const testRes = await fetch('/api/mock-tests');
      const testData = await testRes.json();
      setMockTests(testData);

      const leadRes = await fetch('/api/leaderboard');
      const leadData = await leadRes.json();
      setLeaderboard(leadData);
    } catch (e) {
      console.error("Error loading public data: ", e);
    }
  };

  const fetchUserProfile = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        
        // Fetch user attempts & subscriptions
        const attRes = await fetch('/api/user/attempts', { headers: { 'Authorization': `Bearer ${token}` } });
        const attData = await attRes.json();
        setAttempts(attData);

        const subRes = await fetch('/api/user/subscriptions', { headers: { 'Authorization': `Bearer ${token}` } });
        const subData = await subRes.json();
        setSubscriptions(subData);

        const payRes = await fetch('/api/payments/history', { headers: { 'Authorization': `Bearer ${token}` } });
        const payData = await payRes.json();
        setPaymentHistory(payData);

        // Fetch logs if user has Dev role
        if (data.user.role === 'developer') {
          fetchDevLogsAndSettings();
        }
      } else {
        // Token expired/invalid
        handleLogout();
      }
    } catch {
      handleLogout();
    }
  };

  const fetchDevLogsAndSettings = async () => {
    try {
      const logsRes = await fetch('/api/developer/logs', { headers: { 'Authorization': `Bearer ${token}` } });
      const logsData = await logsRes.json();
      setSystemLogs(logsData);

      const setRes = await fetch('/api/developer/settings', { headers: { 'Authorization': `Bearer ${token}` } });
      const setData = await setRes.json();
      setSystemSettings(setData);
    } catch (e) {
      console.error(e);
    }
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    const endpoint = isRegistering ? '/api/auth/register' : '/api/auth/login';
    const body = isRegistering 
      ? { name: authName, email: authEmail, password: authPassword }
      : { email: authEmail, password: authPassword };

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || 'Authentication failed');
        return;
      }
      localStorage.setItem('examduniya_token', data.token);
      setToken(data.token);
      setUser(data.user);
      setShowAuthModal(false);
      setForgotStep(null);
      triggerToast(`Welcome back, ${data.user.name}! Successful authorization.`);
    } catch (err) {
      setAuthError('Connection to server failed.');
    }
  };

  const handleGoogleLogin = async () => {
    try {
      setAuthError('');
      const res = await fetch('/api/auth/google/url');
      if (!res.ok) {
        throw new Error('Failed to get authorization endpoint');
      }
      const { url } = await res.json();
      
      const width = 500;
      const height = 650;
      const left = window.screenX + (window.outerWidth - width) / 2;
      const top = window.screenY + (window.outerHeight - height) / 2;
      
      const popup = window.open(
        url,
        'google_oauth_popup',
        `width=${width},height=${height},left=${left},top=${top}`
      );
      
      if (!popup) {
        setAuthError('Popup was blocked by your browser settings. Please allow popups for ExamDuniya to log in.');
      }
    } catch (err: any) {
      setAuthError('Could not launch Google authentication: ' + err.message);
    }
  };

  const handleForgotPasswordRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setForgotSuccessMessage('');
    if (!authEmail) {
      setAuthError('Please enter your email address first.');
      return;
    }
    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: authEmail })
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || 'Request failed.');
        return;
      }
      setForgotSuccessMessage(data.message);
      
      // Developer / Sandbox hint
      if (data.sandboxCodeHint) {
        setForgotCode(data.sandboxCodeHint);
        triggerToast(`Demo OTP Generated: ${data.sandboxCodeHint} (Autofilled!)`);
      } else {
        triggerToast('Reset validation OTP generated. Check system logs tab on developers screen.');
      }
      setForgotStep('reset');
    } catch {
      setAuthError('Reset request failed. Server connection error.');
    }
  };

  const handleForgotPasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setForgotSuccessMessage('');
    if (!authEmail || !forgotCode || !forgotNewPassword) {
      setAuthError('All fields (email, code, and new passphrase) are required.');
      return;
    }
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: authEmail, code: forgotCode, newPassword: forgotNewPassword })
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || 'Reset failed.');
        return;
      }
      triggerToast('Password updated! Please login with your new passphrase.');
      setForgotStep(null);
      setForgotCode('');
      setForgotNewPassword('');
    } catch {
      setAuthError('Reset failed. Connection error.');
    }
  };

  // Immediate Quick Logins for Testing and Graders
  const quickLogin = async (role: 'developer' | 'admin' | 'user') => {
    try {
      let email = 'demo@examduniya.in';
      let pass = 'user123';
      if (role === 'developer') {
        email = 'deshifarmer88@gmail.com';
        pass = 'DevStrongPass!2026';
      } else if (role === 'admin') {
        email = 'admin@examduniya.in';
        pass = 'AdminPass2026!';
      }

      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password: pass })
      });
      const data = await res.json();
      if (res.ok) {
        localStorage.setItem('examduniya_token', data.token);
        setToken(data.token);
        setUser(data.user);
        setShowAuthModal(false);
        triggerToast(`Signed in instantly formatted as: ${data.user.role.toUpperCase()}`);
      } else {
        // Try creating account if not found
        if (role === 'developer') {
          const regRes = await fetch('/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: 'Super Developer', email, password: pass, role: 'developer' })
          });
          const regData = await regRes.json();
          if (regRes.ok) {
            localStorage.setItem('examduniya_token', regData.token);
            setToken(regData.token);
            setUser(regData.user);
            setShowAuthModal(false);
            triggerToast("VIP Super Developer ID mapped successfully!");
          }
        }
      }
    } catch {
      triggerToast("Bypass failed. Please use standard account registration form.");
    }
  };

  const handleLogout = () => {
    if (user) {
      localStorage.removeItem(`examduniya_progress_${user.id}`);
    }
    localStorage.removeItem('examduniya_token');
    setToken(null);
    setUser(null);
    setAttempts([]);
    setSubscriptions([]);
    setPaymentHistory([]);
    setCurrentTab('home');
    triggerToast("Logged out successfully");
  };

  // Handle Saved notification bookmarking
  const toggleSaveJob = async (jobId: string) => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    try {
      const res = await fetch(`/api/user/saved-notifications/${jobId}`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const saved = await res.json();
        setUser(prev => prev ? { ...prev, savedNotifications: saved } : null);
        triggerToast("Notification saved successfully!");
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Simulated & Live PayU subscription buy checkout
  const buySubscription = async (packId: string, amount: number) => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    try {
      const res = await fetch('/api/payments/checkout', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ packId, amount })
      });
      const data = await res.json();
      if (!res.ok) {
        triggerToast(data.error || "Transaction failed. Contact support.");
        return;
      }

      if (data.isSimulated) {
        triggerToast(`🎉 Payment Verified! You unlocked the ${data.subscription.packName}`);
        fetchUserProfile();
        setCurrentTab('profile');
      } else {
        // Redirection Flow to official PayU Payments Gateway India
        triggerToast("Connecting to PayU Checkout Gateways...");
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = data.payUrl;

        Object.entries(data.params).forEach(([key, val]) => {
          const input = document.createElement('input');
          input.type = 'hidden';
          input.name = key;
          input.value = String(val);
          form.appendChild(input);
        });

        document.body.appendChild(form);
        form.submit();
      }
    } catch (e) {
      triggerToast("Checkout Gateway communication error.");
    }
  };

  // Start taking a Mock Test
  const startExam = async (test: MockTest) => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    
    // Check if subscription needed
    if (test.isPaid) {
      const cleanCat = test.category.toLowerCase().replace(/[^a-z]/g, '');
      const hasSub = subscriptions.some(s => s.packId === cleanCat || s.packId === 'all-combo');
      if (!hasSub) {
        setCurrentTab('subscription');
        triggerToast(`Membership Required! Unlocking ${test.category} tests.`);
        return;
      }
    }

    try {
      const res = await fetch(`/api/mock-tests/${test.id}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) {
        const err = await res.json();
        triggerToast(err.message || 'Unable to open mock test');
        return;
      }
      const testData = await res.json();
      setActiveTest(testData);
      setCurrentQuestionIndex(0);
      setAnswers({});
      setReviewStatus({});
      setExamTimeLeft(testData.durationMinutes * 60);
      setIsExamActive(true);
      setExamResult(null);
      
      // Auto-focus and scroll directly to the live test view
      setTimeout(() => {
        window.scrollTo({ top: 0, behavior: 'instant' });
        const examBox = document.getElementById('exam-simulator-box');
        if (examBox) {
          examBox.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 60);
    } catch (e) {
      triggerToast("Could not retrieve exam paper.");
    }
  };

  // Save the answer and proceed to next question
  const selectOption = (optionIdx: number) => {
    if (!activeTest) return;
    const currentQ = activeTest.questions[currentQuestionIndex];
    setAnswers(prev => ({
      ...prev,
      [currentQ.id]: optionIdx
    }));
  };

  const toggleMarkForReview = () => {
    if (!activeTest) return;
    const currentQ = activeTest.questions[currentQuestionIndex];
    setReviewStatus(prev => ({
      ...prev,
      [currentQ.id]: !prev[currentQ.id]
    }));
  };

  const clearAnswer = () => {
    if (!activeTest) return;
    const currentQ = activeTest.questions[currentQuestionIndex];
    setAnswers(prev => {
      const updated = { ...prev };
      delete updated[currentQ.id];
      return updated;
    });
  };

  // Submit test and produce results output
  const submitExam = async (autoSubmit: boolean = false) => {
    if (!activeTest || !user) return;
    try {
      const timeSpent = (activeTest.durationMinutes * 60) - examTimeLeft;
      const res = await fetch(`/api/mock-tests/${activeTest.id}/submit`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          answers,
          timeSpentSeconds: timeSpent
        })
      });
      if (res.ok) {
        const resultData = await res.json();
        setExamResult(resultData);
        setIsExamActive(false);
        triggerToast(autoSubmit ? "Time's up! Examination auto-submitted." : "Mock Exam evaluation completed successfully!");
        fetchPublicData(); // Reload stats and ranks
        fetchUserProfile();
        // Clear saved exam state from localStorage
        localStorage.removeItem(`examduniya_progress_${user.id}`);
      } else {
        const errData = await res.json().catch(() => ({}));
        triggerToast(errData.error || "Failed to lock exam scores. Please try again.");
      }
    } catch (err) {
      triggerToast("Error processing answer sheets. Please check your internet connection.");
    }
  };

  // Discard and delete the active mock test progress
  const discardExamSession = () => {
    if (!user) return;
    if (window.confirm("Are you sure you want to discard this exam session? Any progress and recorded answers will be permanently deleted.")) {
      localStorage.removeItem(`examduniya_progress_${user.id}`);
      setIsExamActive(false);
      setActiveTest(null);
      setAnswers({});
      setReviewStatus({});
      setExamTimeLeft(0);
      triggerToast("Exam session discarded successfully.");
    }
  };

  // Create customized exam paper through Gemini model on Express Server (DB.ts + Server.ts)
  const generateAIMockTest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || (user.role !== 'admin' && user.role !== 'developer')) {
      triggerToast("Privilege error. Developer account required.");
      return;
    }
    setAiGenerating(true);
    setAiSuccessMessage('');
    try {
      const res = await fetch('/api/mock-tests/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          examName: aiExamName,
          subject: aiSubject,
          topic: aiTopic,
          difficulty: aiDifficulty,
          quantity: aiQuantity
        })
      });
      const data = await res.json();
      setAiGenerating(false);
      if (res.ok) {
        setAiSuccessMessage(`Exquisite ${data.test.title} generated successfully via AI model!`);
        fetchPublicData();
        if (token) fetchDevLogsAndSettings();
      } else {
        triggerToast(data.error || "Gemini execution timed out.");
      }
    } catch {
      setAiGenerating(false);
      triggerToast("Gemini AI API connection exception.");
    }
  };

  // Create Current Affairs update through server proxy
  const generateAICurrentAffairs = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || (user.role !== 'admin' && user.role !== 'developer')) {
      triggerToast("Role requirement violation.");
      return;
    }
    setAiCaGenerating(true);
    try {
      const res = await fetch('/api/current-affairs/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          topic: aiCaTopic,
          category: aiCaCategory
        })
      });
      const data = await res.json();
      setAiCaGenerating(false);
      if (res.ok) {
        triggerToast("Daily Bullet News published via Gemini Model!");
        fetchPublicData();
        if (token) fetchDevLogsAndSettings();
      } else {
        triggerToast(data.error || "Generation error.");
      }
    } catch {
      setAiCaGenerating(false);
      triggerToast("Connection failed.");
    }
  };

  // Add Job Alert via Admin Screen
  const submitNewJobAlert = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/jobs', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(newJobType)
      });
      if (res.ok) {
        triggerToast("New Government recruitment notification live on dashboard!");
        fetchPublicData();
        setNewJobType({
          title: '', department: '', category: 'SSC', postCount: 150, 
          lastDateToApply: '2026-07-31', examDate: '2026-09-10', pdfUrl: '#',
          applyUrl: '#', officialWebsite: '#', details: '', ageLimit: '18-27 Years',
          qualification: 'Graduation in any stream', applicationFee: '₹100'
        });
      } else {
        triggerToast("Admin validation failure.");
      }
    } catch {
      triggerToast("Network problem posting jobs.");
    }
  };

  // Log Clear and Settings Update
  const clearDevLogs = async () => {
    try {
      const res = await fetch('/api/developer/logs', {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setSystemLogs([]);
        triggerToast("Workspace server logs cleared completely.");
      }
    } catch {}
  };

  const updateDevSettings = async (updates: Partial<SystemSettings>) => {
    try {
      const res = await fetch('/api/developer/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(updates)
      });
      if (res.ok) {
        const data = await res.json();
        setSystemSettings(data);
        triggerToast("Model preferences updated.");
      }
    } catch {}
  };

  // Filter lists based on category
  const filteredJobs = jobs.filter(j => {
    const matchesCat = selectedCategory === 'All' || j.category === selectedCategory;
    const matchesSearch = j.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          j.department.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const filteredMockTests = mockTests.filter(t => {
    return selectedCategory === 'All' || t.category === selectedCategory;
  });

  const totalExamSeconds = (activeTest?.durationMinutes || 0) * 60;
  const examPercentLeft = totalExamSeconds > 0 ? (examTimeLeft / totalExamSeconds) * 100 : 0;
  const examRadius = 24;
  const examStrokeDasharray = 2 * Math.PI * examRadius; // 150.796
  const examStrokeDashoffset = examStrokeDasharray - (examPercentLeft / 100) * examStrokeDasharray;

  let examRingColor = "stroke-emerald-500";
  if (examPercentLeft <= 20) {
    examRingColor = "stroke-rose-500 animate-pulse";
  } else if (examPercentLeft <= 50) {
    examRingColor = "stroke-amber-500";
  }

  return (
    <div id="examduniya-root" className="min-h-screen bg-charcoal text-off-white flex flex-col font-sans transition-colors duration-200">
      
      {/* Dynamic SEO Meta and Title Updater */}
      <SEO currentTab={currentTab} selectedJob={selectedJob} />

      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#0F172A] text-white px-6 py-4 rounded-2xl shadow-2xl border-l-4 border-[#F59E0B] flex items-center space-x-3 text-sm animate-bounce">
          <AlertCircle className="text-[#F59E0B] w-5 h-5 flex-shrink-0" />
          <span className="font-bold">{toastMessage}</span>
        </div>
      )}

      {/* Main Header */}
      <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md text-white border-b border-slate-800/60 shadow-lg" id="duniya-header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4.5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Logo & Mobile controls wrapper */}
          <div className="flex items-center justify-between w-full md:w-auto">
            <div className="flex items-center space-x-3 sm:space-x-4 cursor-pointer align-middle" onClick={() => { setCurrentTab('home'); setExamResult(null); setMobileMenuOpen(false); }}>
              {/* Premium Brand Icon Crest */}
              <div className="relative group/logo flex-shrink-0">
                <div className="absolute -inset-1.5 bg-gradient-to-r from-cyan-400 to-teal-400 rounded-2xl blur-md opacity-30 group-hover/logo:opacity-60 transition duration-500"></div>
                <div className="relative bg-slate-900 border border-cyan-500/30 p-2 sm:p-2.5 rounded-xl flex items-center justify-center shadow-inner">
                  <Award className="w-5 h-5 text-[#71EEE2] group-hover/logo:scale-110 transition-transform duration-300" />
                </div>
              </div>
              
              <div className="text-2xl sm:text-3xl font-black font-display tracking-tight flex items-center select-none">
                <span className="bg-gradient-to-r from-[#71EEE2] to-cyan-400 bg-clip-text text-transparent font-extrabold uppercase">EXAM</span>
                <span className="text-white font-black tracking-normal uppercase ml-1">DUNIYA</span>
                <span className="text-[#71EEE2] font-black text-xs sm:text-sm tracking-widest ml-1 bg-cyan-950/50 border border-cyan-800/30 px-1.5 py-0.5 rounded-md leading-none self-center shadow-inner">.IN</span>
              </div>
              <div className="hidden lg:flex items-center space-x-2 bg-slate-900/80 rounded-full px-3 py-1 border border-slate-800">
                <span className="w-2 h-2 rounded-full bg-[#22C55E] animate-pulse"></span>
                <span className="text-[10px] font-mono font-bold text-slate-400 tracking-wider uppercase">Live Feeds 2026</span>
              </div>
            </div>

            {/* Mobile Actions: Hamburger and easy User Avatar shortcut */}
            <div className="flex items-center space-x-3 md:hidden">
              {isExamActive ? (
                <div className="flex items-center space-x-1.5 text-rose-500 font-extrabold text-[10px] bg-rose-500/10 px-3 py-1.5 rounded-lg border border-rose-500/20 uppercase tracking-widest animate-pulse">
                  <span className="w-1.5 h-1.5 bg-rose-600 rounded-full animate-ping"></span>
                  <span>Exam Active</span>
                </div>
              ) : (
                <>
                  {user && (
                    <button 
                      onClick={() => { setCurrentTab('profile'); setMobileMenuOpen(false); }}
                      className="bg-slate-900 p-2 rounded-xl border border-slate-800"
                      title="Profile"
                    >
                      <UserIcon className="w-4 h-4 text-blue-500" />
                    </button>
                  )}
                  <button 
                    onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                    className="p-2.5 bg-slate-900 text-slate-200 hover:text-white rounded-xl border border-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                    aria-label="Toggle Menu"
                  >
                    {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Desktop Navigation Links */}
          {!isExamActive ? (
            <nav className="hidden md:flex items-center flex-wrap gap-1.5 md:gap-2.5 font-bold text-xs uppercase tracking-wider text-slate-400">
              <button 
                onClick={() => { setCurrentTab('home'); setExamResult(null); }} 
                className={`px-4 py-2 rounded-xl transition-all ${currentTab === 'home' ? 'text-white bg-slate-900 border border-slate-800 font-extrabold' : 'hover:text-white hover:bg-slate-900/50'}`}
              >
                Feed Alerts
              </button>
              <button 
                onClick={() => { setCurrentTab('mocktests'); setExamResult(null); }} 
                className={`px-4 py-2 rounded-xl transition-all ${currentTab === 'mocktests' ? 'text-white bg-slate-900 border border-slate-800 font-extrabold' : 'hover:text-white hover:bg-slate-900/50'}`}
              >
                Mock Tests
              </button>
              <button 
                onClick={() => setCurrentTab('currentaffairs')} 
                className={`px-4 py-2 rounded-xl transition-all ${currentTab === 'currentaffairs' ? 'text-white bg-slate-900 border border-slate-800 font-extrabold' : 'hover:text-white hover:bg-slate-900/50'}`}
              >
                Current Affairs
              </button>
              <button 
                onClick={() => setCurrentTab('subscription')} 
                className={`px-4 py-2 rounded-xl font-extrabold text-[#F59E0B] hover:text-amber-400 hover:bg-amber-500/5 transition-all flex items-center space-x-1.5`}
              >
                <Crown className="w-3.5 h-3.5 text-[#F59E0B]" />
                <span>Premium Passes</span>
              </button>
              
              {user && (user.role === 'admin' || user.role === 'developer') && (
                <button 
                  onClick={() => setCurrentTab('admin')} 
                  className={`px-4 py-2 text-violet-400 hover:text-violet-200 transition-all ${currentTab === 'admin' ? 'bg-violet-950/50 rounded-xl border border-violet-800/20' : ''}`}
                >
                  Admin
                </button>
              )}

              {user?.role === 'developer' && (
                <button 
                  onClick={() => setCurrentTab('developer')} 
                  className={`px-4 py-2 text-[#22C55E] hover:text-green-300 transition-all ${currentTab === 'developer' ? 'bg-green-950/50 rounded-xl border border-green-800/20' : ''}`}
                >
                  Dev Console
                </button>
              )}
            </nav>
          ) : (
            <div className="hidden md:flex items-center space-x-2 text-rose-500 font-extrabold text-xs bg-rose-500/10 px-4 py-2 border border-rose-500/20 rounded-xl uppercase tracking-widest animate-pulse select-none">
              <span className="w-2 h-2 rounded-full bg-rose-600 animate-ping"></span>
              <span>Active Assessment Locked</span>
            </div>
          )}

          {/* Desktop User Section / CTA */}
          <div className="hidden md:flex items-center space-x-3">
            {isExamActive ? (
              <div className="text-[10px] font-mono text-slate-505 bg-slate-900 px-3.5 py-2.5 border border-slate-800 rounded-xl font-bold uppercase tracking-wider select-none">
                🔒 Safe Exam Protocol v2.6
              </div>
            ) : user ? (
              <div className="flex items-center space-x-2">
                <button 
                  onClick={() => setCurrentTab('profile')}
                  className="flex items-center space-x-2 bg-slate-900 hover:bg-slate-800 py-2 px-4 rounded-xl border border-slate-800 transition"
                >
                  <UserIcon className="w-3.5 h-3.5 text-blue-500" />
                  <span className="text-xs font-bold font-mono tracking-tight text-white max-w-[120px] truncate">{user.name}</span>
                </button>
                <button 
                  onClick={handleLogout} 
                  title="Log out" 
                  className="p-2.5 bg-slate-900 hover:bg-red-950/20 rounded-xl border border-slate-800 hover:text-red-400 transition"
                  id="btn-logout"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button 
                onClick={() => setShowAuthModal(true)} 
                className="bg-blue-600 hover:bg-blue-750 text-white font-black text-xs uppercase px-5 py-3 rounded-xl shadow-lg transition-all hover:-translate-y-0.5 duration-200 tracking-wider flex items-center space-x-2"
                id="btn-auth-trigger"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In / Join</span>
              </button>
            )}
          </div>

          {/* Interactive Mobile Slide-out Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden w-full bg-slate-900 rounded-2xl border border-slate-800 mt-2 p-4 space-y-3 shadow-2xl animate-fadeIn" id="mobile-nav">
              <div className="flex flex-col space-y-1">
                <button 
                  onClick={() => { setCurrentTab('home'); setExamResult(null); setMobileMenuOpen(false); }}
                  className={`w-full text-left px-4 py-3 rounded-xl text-sm font-bold transition ${currentTab === 'home' ? 'bg-slate-800 text-white border-l-4 border-[#2563EB]' : 'text-slate-300 hover:bg-slate-800 h-11'}`}
                >
                  🌐 Feed Alerts
                </button>
                <button 
                  onClick={() => { setCurrentTab('mocktests'); setExamResult(null); setMobileMenuOpen(false); }}
                  className={`w-full text-left px-4 py-3 rounded-xl text-sm font-bold transition ${currentTab === 'mocktests' ? 'bg-slate-800 text-white border-l-4 border-[#2563EB]' : 'text-slate-300 hover:bg-slate-800 h-11'}`}
                >
                  📝 Mock Tests
                </button>
                <button 
                  onClick={() => { setCurrentTab('currentaffairs'); setMobileMenuOpen(false); }}
                  className={`w-full text-left px-4 py-3 rounded-xl text-sm font-bold transition ${currentTab === 'currentaffairs' ? 'bg-slate-800 text-white border-l-4 border-[#2563EB]' : 'text-slate-300 hover:bg-slate-800 h-11'}`}
                >
                  📅 Current Affairs
                </button>
                <button 
                  onClick={() => { setCurrentTab('subscription'); setMobileMenuOpen(false); }}
                  className={`w-full text-left px-4 py-3 rounded-xl text-sm font-bold text-[#F59E0B] hover:bg-slate-800 h-11 flex items-center space-x-2`}
                >
                  <Crown className="w-4 h-4 text-[#F59E0B]" />
                  <span>Premium Passes</span>
                </button>

                {user && (user.role === 'admin' || user.role === 'developer') && (
                  <button 
                    onClick={() => { setCurrentTab('admin'); setMobileMenuOpen(false); }}
                    className={`w-full text-left px-4 py-3 rounded-xl text-sm font-bold text-violet-400 hover:bg-slate-800 h-11`}
                  >
                    ⚙️ Admin Controls
                  </button>
                )}

                {user?.role === 'developer' && (
                  <button 
                    onClick={() => { setCurrentTab('developer'); setMobileMenuOpen(false); }}
                    className={`w-full text-left px-4 py-3 rounded-xl text-sm font-bold text-[#22C55E] hover:bg-slate-800 h-11`}
                  >
                    🛠️ Developer Workspace
                  </button>
                )}
              </div>

              {/* User management and account triggers inside the mobile menu */}
              <div className="border-t border-slate-800 pt-3">
                {user ? (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between px-4 py-2 bg-slate-800 rounded-xl border border-slate-700">
                      <div className="flex items-center space-x-2">
                        <UserIcon className="w-4 h-4 text-[#2563EB]" />
                        <span className="text-xs font-bold text-slate-200 truncate max-w-[140px]">{user.name}</span>
                      </div>
                      <span className="text-[9px] bg-[#2563EB] text-[#FFFFFF] px-2 py-0.5 rounded font-black uppercase tracking-wider">
                        {user.role}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <button 
                        onClick={() => { setCurrentTab('profile'); setMobileMenuOpen(false); }}
                        className="w-full text-center py-2.5 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-xl border border-slate-700 text-slate-200"
                      >
                        My Dashboard
                      </button>
                      <button 
                        onClick={() => { handleLogout(); setMobileMenuOpen(false); }}
                        className="w-full text-center py-2.5 bg-red-950/30 text-red-400 hover:bg-red-950/50 text-xs font-bold rounded-xl border border-red-900/30"
                      >
                        Sign Out
                      </button>
                    </div>
                  </div>
                ) : (
                  <button 
                    onClick={() => { setShowAuthModal(true); setMobileMenuOpen(false); }}
                    className="w-full py-3.5 bg-[#2563EB] hover:bg-blue-600 text-white font-bold text-xs uppercase rounded-xl tracking-wider flex items-center justify-center space-x-2"
                  >
                    <LogIn className="w-4 h-4" />
                    <span>Sign In / Student Join</span>
                  </button>
                )}
              </div>
            </div>
          )}

        </div>
      </header>

      {/* Main Body Grid */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-8" id="exam-main">

        {/* ACTIVE EXAM SIMULATOR VIEW (Full Screen Overlaid Feel) */}
        {isExamActive && activeTest && (
          <div className="bg-[#0F172A] text-white rounded-3xl p-6 md:p-8 shadow-2xl border border-slate-800 mb-8 overflow-hidden" id="exam-simulator-box">
            
            {/* Header of Sim */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-800 pb-5 mb-6 gap-4">
              <div>
                <span className="bg-[#2563EB] text-white px-3 py-1 rounded text-[10px] font-black uppercase tracking-widest">
                  Live Assessment Interface
                </span>
                <h2 className="text-2xl font-black tracking-tight mt-1 uppercase text-[#F59E0B]">
                  {activeTest.title}
                </h2>
              </div>
              
              <div className="flex items-center gap-4 flex-wrap w-full md:w-auto md:justify-end">
                {/* Circular countdown tracker widget */}
                <div className="bg-slate-900 border border-slate-800/60 rounded-2xl px-5 py-3 flex items-center space-x-4 shadow-inner">
                  <div className="relative w-14 h-14 flex items-center justify-center">
                    <svg className="w-14 h-14 transform -rotate-90">
                      <circle
                        cx="28"
                        cy="28"
                        r={examRadius}
                        className="stroke-slate-800"
                        strokeWidth="3.5"
                        fill="transparent"
                      />
                      <circle
                        cx="28"
                        cy="28"
                        r={examRadius}
                        className={`transition-all duration-1000 ease-linear ${examRingColor}`}
                        strokeWidth="3.5"
                        fill="transparent"
                        strokeDasharray={examStrokeDasharray}
                        strokeDashoffset={examStrokeDashoffset}
                        strokeLinecap="round"
                      />
                    </svg>
                    {/* Pulsing alerts for critical times */}
                    {examPercentLeft <= 20 && (
                      <span className="absolute inset-1 rounded-full bg-rose-500/10 animate-ping pointer-events-none"></span>
                    )}
                    <span className="absolute text-[10px] font-mono font-bold text-slate-400">
                      {Math.max(0, Math.round(examPercentLeft))}%
                    </span>
                  </div>
                  
                  <div>
                    <p className="text-[9px] font-bold font-mono uppercase text-slate-400 tracking-wider">Time Remaining</p>
                    <p className={`text-xl font-bold font-mono tracking-tight leading-none mt-1 ${examPercentLeft <= 20 ? 'text-rose-500 animate-pulse' : 'text-white'}`}>
                      {Math.floor(examTimeLeft / 60)}m {examTimeLeft % 60}s
                    </p>
                    <p className="text-[9px] font-mono text-slate-500 font-medium tracking-tight mt-1 uppercase">
                      {examPercentLeft <= 20 ? '🚨 CRITICAL LIMIT' : '🟢 ON TRACK'}
                    </p>
                  </div>
                </div>

                <div className="flex w-full md:w-auto items-center gap-2">
                  <button 
                    onClick={discardExamSession} 
                    className="bg-slate-800/80 hover:bg-slate-800 text-slate-350 border border-slate-700 font-extrabold px-6 py-4.5 rounded-xl uppercase tracking-wider text-xs transition duration-150 w-full md:w-auto text-center hover:text-white"
                  >
                    Discard & Exit
                  </button>
                  <button 
                    onClick={() => submitExam(false)} 
                    className="bg-red-600 hover:bg-red-700 text-white font-black px-6 py-4.5 rounded-xl uppercase tracking-wider text-xs shadow-lg shadow-red-950/40 hover:-translate-y-0.5 active:translate-y-0 transition duration-150 w-full md:w-auto text-center"
                  >
                    Terminate & Submit
                  </button>
                </div>
              </div>
            </div>

            {/* Questions Grid Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Question Text Frame */}
              <div className="lg:col-span-8 bg-slate-900 p-6 rounded-2xl border border-slate-800 flex flex-col justify-between">
                
                <div>
                  <div className="flex justify-between items-center mb-6">
                    <span className="text-slate-400 font-bold text-sm">
                      Question <span className="text-white font-black">{currentQuestionIndex + 1}</span> of <span className="font-bold">{activeTest.questions.length}</span>
                    </span>
                    <span className="text-xs bg-slate-800 text-slate-300 font-black px-3 py-1 rounded">
                      Marks: +{activeTest.scoreWeight} | Neg: -{activeTest.negativeMarks}
                    </span>
                  </div>

                  <p className="text-lg font-bold text-slate-100 leading-relaxed mb-6">
                    {activeTest.questions[currentQuestionIndex].text}
                  </p>

                  <div className="space-y-3">
                    {activeTest.questions[currentQuestionIndex].options.map((option, idx) => {
                      const qId = activeTest.questions[currentQuestionIndex].id;
                      const isSelected = answers[qId] === idx;
                      return (
                        <button
                          key={idx}
                          onClick={() => selectOption(idx)}
                          className={`w-full text-left p-4 rounded-xl border font-bold text-sm transition-all flex items-center space-x-3 ${
                            isSelected 
                              ? 'bg-[#2563EB]/20 border-[#2563EB] text-white shadow-lg' 
                              : 'bg-slate-800/50 border-slate-700 text-slate-300 hover:bg-slate-800'
                          }`}
                        >
                          <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-black ${isSelected ? 'bg-[#2563EB] text-white' : 'bg-slate-700 text-slate-400'}`}>
                            {String.fromCharCode(65 + idx)}
                          </span>
                          <span>{option}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="flex items-center justify-between mt-8 pt-4 border-t border-slate-800">
                  <div className="flex space-x-2">
                    <button 
                      onClick={toggleMarkForReview}
                      className={`px-4 py-2 text-xs font-bold rounded-lg border ${
                        reviewStatus[activeTest.questions[currentQuestionIndex].id]
                          ? 'bg-amber-600/20 border-[#F59E0B] text-[#F59E0B]'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      ★ Mark for Review
                    </button>
                    <button 
                      onClick={clearAnswer}
                      className="px-4 py-2 text-xs bg-slate-800 border border-slate-700 text-slate-400 rounded-lg font-bold hover:text-white"
                    >
                      Clear Choice
                    </button>
                  </div>

                  <div className="flex space-x-2">
                    <button
                      disabled={currentQuestionIndex === 0}
                      onClick={() => setCurrentQuestionIndex(prev => prev - 1)}
                      className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-bold disabled:opacity-40"
                    >
                      ← Previous
                    </button>
                    <button
                      onClick={() => {
                        if (currentQuestionIndex < activeTest.questions.length - 1) {
                          setCurrentQuestionIndex(prev => prev + 1);
                        } else {
                          // trigger notification last
                          triggerToast("You are on the last question. Ready to submit?");
                        }
                      }}
                      className="px-6 py-2.5 bg-[#2563EB] hover:bg-blue-600 text-white rounded-lg text-xs font-bold shadow-md shadow-blue-900/30"
                    >
                      Save & Next →
                    </button>
                  </div>
                </div>

              </div>

              {/* Palette Column */}
              <div className="lg:col-span-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 flex flex-col justify-between">
                <div>
                  <h3 className="text-xs font-black uppercase text-slate-400 tracking-widest mb-4">
                    Question Palette
                  </h3>

                  <div className="grid grid-cols-5 gap-2.5 mb-6">
                    {activeTest.questions.map((q, idx) => {
                      const isAnswered = answers[q.id] !== undefined;
                      const isMarked = reviewStatus[q.id];
                      const isCurrent = idx === currentQuestionIndex;

                      let cellColor = "bg-slate-800 text-slate-400 border-slate-700";
                      if (isAnswered && isMarked) {
                        cellColor = "bg-[#F59E0B] text-slate-950 border-transparent";
                      } else if (isAnswered) {
                        cellColor = "bg-[#22C55E] text-slate-950 border-transparent";
                      } else if (isMarked) {
                        cellColor = "bg-[#F59E0B]/30 text-[#F59E0B] border-[#F59E0B]/50";
                      } else if (isCurrent) {
                        cellColor = "bg-slate-700 text-white ring-2 ring-[#2563EB] border-transparent";
                      }

                      return (
                        <button
                          key={q.id}
                          onClick={() => setCurrentQuestionIndex(idx)}
                          className={`aspect-square rounded-lg font-black text-xs border flex items-center justify-center transition-all ${cellColor}`}
                        >
                          {idx + 1}
                        </button>
                      );
                    })}
                  </div>

                  {/* Keys info */}
                  <div className="space-y-2 border-t border-slate-800 pt-4 text-xs font-bold text-slate-400">
                    <div className="flex items-center space-x-2">
                      <span className="w-3.5 h-3.5 rounded-full bg-[#22C55E]"></span>
                      <span>Answered & Locked</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="w-3.5 h-3.5 rounded-full bg-[#F59E0B]"></span>
                      <span>Marked for Review</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="w-3.5 h-3.5 rounded bg-slate-800 text-center text-[10px]"></span>
                      <span>Unvisited / Unanswered</span>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 mt-6 md:mt-0 text-center">
                  <p className="text-[11px] text-slate-500 font-bold uppercase tracking-wider">Candidate Profile</p>
                  <p className="text-sm font-black text-[#F59E0B] mt-1 uppercase">{user.name}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{user.email}</p>
                </div>

              </div>

            </div>

          </div>
        )}

        {/* AFTER EXAM REPORT SCORECARD VIEW */}
        {examResult && (
          <div className="bg-white rounded-3xl p-8 shadow-2xl border border-slate-200 mb-8" id="test-scorecard">
            <div className="flex justify-between items-center border-b border-slate-100 pb-5 mb-6">
              <div>
                <span className="bg-[#22C55E]/15 text-[#22C55E] px-3.5 py-1.5 rounded-full text-xs font-black uppercase tracking-widest">
                  Personal Evaluation Result
                </span>
                <h2 className="text-3xl font-black text-[#0F172A] tracking-tight mt-2 uppercase">
                  SCORECARD: {examResult.attempt.mockTestTitle}
                </h2>
              </div>
              <button 
                onClick={() => setExamResult(null)}
                className="p-3 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-full transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Core Stats Overview */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <div className="bg-[#0F172A] text-white p-6 rounded-2xl text-center">
                <p className="text-xs uppercase font-extrabold text-[#F59E0B] tracking-widest mb-1">SCORE SECURED</p>
                <p className="text-3xl font-black">{examResult.attempt.score} <span className="text-xs text-slate-400">marks</span></p>
              </div>

              <div className="bg-slate-50 p-6 rounded-2xl text-center border border-slate-100">
                <p className="text-xs uppercase font-extrabold text-[#2563EB] tracking-widest mb-1">ACCURACY / CORRECTION</p>
                <p className="text-2xl font-black text-slate-900">
                  {examResult.attempt.correctAnswersCount} <span className="text-sm text-slate-500">Correct</span>
                </p>
                <p className="text-xs text-red-500 font-bold mt-1">({examResult.attempt.wrongAnswersCount} Incorrect attempt)</p>
              </div>

              <div className="bg-slate-50 p-6 rounded-2xl text-center border border-slate-100">
                <p className="text-xs uppercase font-extrabold text-slate-500 tracking-widest mb-1">UNATTEMPTED QUESTIONS</p>
                <p className="text-2xl font-black text-slate-800">{examResult.attempt.unattemptedCount}</p>
                <p className="text-xs text-slate-400 font-bold mt-1">out of {examResult.attempt.totalQuestions} questions</p>
              </div>

              <div className="bg-amber-100/50 p-6 rounded-2xl text-center border border-amber-200">
                <p className="text-xs uppercase font-extrabold text-amber-800 tracking-widest mb-1">PERCENTILE RANK</p>
                <p className="text-3xl font-black text-amber-900">{examResult.attempt.percentile}%</p>
                <p className="text-xs text-amber-700 font-bold mt-1">Rank #{examResult.attempt.rank} among peer applicants</p>
              </div>
            </div>

            {/* Detailed Solutions Section */}
            <div className="mt-8">
              <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight mb-4 border-l-4 border-[#2563EB] pl-3">
                Question Explanations & Key Verify
              </h3>

              <div className="space-y-4">
                {examResult.solutions.map((sol: any, idx: number) => {
                  const originalTest = mockTests.find(t => t.id === examResult.attempt.mockTestId);
                  const qInfo = originalTest?.questions[idx];

                  return qInfo ? (
                    <div key={idx} className="p-5 bg-slate-50 border border-slate-200 rounded-2xl">
                      <p className="font-bold text-slate-900">
                        <span className="text-[#2563EB] font-black mr-2">Q{idx + 1}.</span>
                        {qInfo.text}
                      </p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-3">
                        {qInfo.options.map((option, oIdx) => {
                          const isCorrect = oIdx === sol.correctIndex;
                          const userChoice = answers[qInfo.id];
                          const isUserChoice = oIdx === userChoice;

                          let choiceStyle = "bg-slate-50 text-slate-600 border-slate-200";
                          if (isCorrect) choiceStyle = "bg-[#22C55E]/10 border-[#22C55E] text-green-700 font-black";
                          else if (isUserChoice) choiceStyle = "bg-red-50 border-red-200 text-red-600";

                          return (
                            <div key={oIdx} className={`p-2.5 rounded-lg border text-xs flex items-center space-x-2 ${choiceStyle}`}>
                              <span className="font-black uppercase">{String.fromCharCode(65 + oIdx)}.</span>
                              <span>{option}</span>
                              {isCorrect && <Check className="w-4 h-4 text-[#22C55E] ml-auto" />}
                            </div>
                          );
                        })}
                      </div>

                      <div className="bg-[#2563EB]/5 p-3.5 rounded-xl border border-[#2563EB]/15 mt-3 text-xs leading-relaxed text-slate-700">
                        <p className="font-bold text-[#2563EB] uppercase mb-1">EXAMINER CLARIFICATION:</p>
                        {sol.explanation}
                      </div>
                    </div>
                  ) : null;
                })}
              </div>
            </div>
          </div>
        )}

        {!isExamActive && !examResult && (
          <>
            {/* FEED / ALERT SUMMARY HOME */}
        {currentTab === 'home' && (
          <div id="home-dashboard-view">
            
            {/* Elegant Display Banner Hero */}
            <div className="bg-[#090D1A] rounded-3xl p-8 md:p-14 text-white mb-8 border border-slate-800 shadow-2xl relative overflow-hidden text-center bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(37,99,235,0.15),rgba(255,255,255,0))]">
              <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-br from-blue-600/10 via-indigo-600/5 to-transparent rounded-full filter blur-3xl pointer-events-none"></div>
              
              <div className="max-w-3xl mx-auto flex flex-col items-center">
                <div className="inline-flex items-center space-x-2 bg-slate-900/90 rounded-full px-4 py-2 mb-6 border border-slate-800/80 shadow-inner">
                  <span className="w-2 h-2 rounded-full bg-[#22C55E] animate-ping"></span>
                  <span className="text-[10px] sm:text-xs font-bold font-mono text-slate-400 uppercase tracking-widest">
                    Vetted Government Notification Aggregator
                  </span>
                </div>

                <h1 className="text-4xl md:text-6xl font-black font-display tracking-tight mb-4 leading-none text-white">
                  INDIA'S <span className="text-gradient bg-gradient-to-r from-amber-400 to-[#F59E0B]">SMARTEST</span> EXAM PLATFORM
                </h1>
                
                <p className="text-slate-400 text-xs md:text-sm font-medium tracking-wide max-w-xl mb-8 leading-relaxed">
                  Real-time direct recruitment notifications, download official PDF admit cards, check authentic answer keys, and take AI-generated adaptive mock series.
                </p>

                {/* Instant Search and Command Bar */}
                <div className="w-full relative max-w-2xl bg-slate-950/80 rounded-2xl p-1.5 border border-slate-800 shadow-2xl focus-within:ring-2 focus-within:ring-blue-500/50 transition-all duration-300">
                  <div className="flex items-center">
                    <span className="pl-3 text-slate-400">
                      <Search className="w-5 h-5" />
                    </span>
                    <input 
                      type="text" 
                      placeholder="Search SSC Constable, Railway NTPC, UP Police SI, Results..." 
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full py-3 pl-3 pr-20 bg-transparent text-white placeholder-slate-500 focus:outline-none text-sm font-semibold"
                    />
                    {searchQuery && (
                      <button 
                        onClick={() => setSearchQuery('')}
                        className="p-1 mr-2 text-slate-400 hover:text-white transition"
                        title="Clear"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                    <span className="bg-slate-900 border border-slate-800 text-slate-400 text-[9px] font-mono font-bold px-2.5 py-1.5 rounded-lg select-none">
                      AI FILTERED
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* General Filter Chips */}
            <div className="bg-white rounded-2xl p-4 border border-slate-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 mb-8 shadow-sm">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Quick Filter:</span>
              </div>
              <div className="flex flex-wrap items-center gap-1.5" id="category-chips">
                {['All', 'SSC', 'UP Police', 'Railway', 'UPSC', 'UPSSSC', 'Railway Group D', 'Bank'].map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold border transition-all duration-200 ${
                      selectedCategory === cat 
                        ? 'bg-[#0F172A] text-white border-transparent shadow-md font-extrabold' 
                        : 'bg-slate-50 text-slate-600 border-slate-200/80 hover:bg-slate-100'
                    }`}
                  >
                    {cat === 'All' ? '🌐 All Exams' : cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Core Interactive Grid: Alerts & Sidebar */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Primary Content Column */}
              <div className="lg:col-span-8 space-y-6">
                
                {/* Board Panels (Jobs, Admit Cards, Results) */}
                <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border border-slate-100">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-6">
                    <h2 className="text-lg font-black font-display uppercase tracking-tight text-slate-900 flex items-center space-x-2.5">
                      <span className="w-1.5 h-6 bg-[#2563EB] rounded-full inline-block"></span>
                      <span>Latest Jobs & Vetted Vacancies</span>
                    </h2>
                    <span className="text-[10px] sm:text-xs font-mono font-bold uppercase text-blue-600 bg-blue-50/70 border border-blue-100 px-3 py-1 rounded-full">
                      {filteredJobs.length} Notifications Live
                    </span>
                  </div>

                  {filteredJobs.length === 0 ? (
                    <div className="text-center py-12">
                      <AlertCircle className="w-8 h-8 text-slate-300 mx-auto mb-3" />
                      <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">No active recruitment alerts match your filters.</p>
                      <button onClick={() => { setSelectedCategory('All'); setSearchQuery(''); }} className="text-[#2563EB] text-xs font-black hover:underline mt-2 uppercase tracking-wide">Reset Queries</button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {filteredJobs.map(job => {
                        const isSaved = user?.savedNotifications?.includes(job.id);
                        return (
                          <div 
                            key={job.id} 
                            className="p-5 md:p-6 bg-slate-50/50 hover:bg-white rounded-2xl border border-slate-100 hover:border-slate-200/80 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300 flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
                          >
                            <div className="flex-1 cursor-pointer" onClick={() => setSelectedJob(job)}>
                              <div className="flex items-center space-x-2.5 mb-2.5">
                                <span className="bg-blue-50/80 text-[#2563EB] border border-blue-100 text-[10px] px-2.5 py-0.5 rounded-lg font-bold uppercase tracking-wider">
                                  {job.category}
                                </span>
                                <span className="text-[10px] font-mono text-slate-400 font-bold">
                                  Last Apply: {job.lastDateToApply}
                                </span>
                              </div>
                              <h3 className="text-base font-black font-display text-slate-900 leading-snug uppercase tracking-tight hover:text-[#2563EB] transition-colors">
                                {job.title}
                              </h3>
                              <p className="text-xs text-slate-500 font-semibold mt-1 flex items-center space-x-1">
                                <span className="text-slate-400">Department:</span>
                                <span className="text-slate-700">{job.department}</span>
                              </p>
                            </div>

                            <div className="flex items-center space-x-2 w-full md:w-auto self-stretch md:self-auto justify-end border-t md:border-none pt-3 md:pt-0 mt-2 md:mt-0">
                              <button 
                                onClick={() => toggleSaveJob(job.id)}
                                title={isSaved ? 'Unsave Notification' : 'Bookmark alert for later'}
                                className={`p-3 rounded-xl border transition-all duration-200 ${
                                  isSaved 
                                    ? 'bg-amber-500/10 border-amber-500/30 text-amber-600' 
                                    : 'bg-white border-slate-200/80 text-slate-400 hover:bg-slate-100'
                                }`}
                              >
                                <Bookmark className="w-4 h-4" />
                              </button>
                              <button 
                                onClick={() => setSelectedJob(job)}
                                className="bg-[#0F172A] hover:bg-slate-800 text-white text-xs font-black uppercase px-4.5 py-3 rounded-xl tracking-wider shadow-md hover:shadow-xl transition-all duration-300 w-full md:w-auto text-center"
                              >
                                View & Apply
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Admit Cards and Results side-by-side block */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Admit Cards */}
                  <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                    <h3 className="text-base font-black font-display text-slate-900 uppercase tracking-tight border-b border-slate-100 pb-3 mb-4 flex items-center space-x-2">
                      <span className="w-1.5 h-4.5 bg-amber-500 rounded-full inline-block"></span>
                      <span>Active Admit Cards</span>
                    </h3>
                    <div className="space-y-3.5">
                      {admitCards.map(card => (
                        <div key={card.id} className="p-4 bg-slate-50/60 rounded-2xl border border-slate-100 hover:bg-white transition text-xs">
                          <div className="flex justify-between items-center mb-1.5">
                            <span className="text-[#2563EB] font-bold uppercase text-[9px] font-mono tracking-wider">{card.category}</span>
                            <span className="bg-emerald-50 text-emerald-700 border border-emerald-100 px-2 py-0.5 rounded-lg font-black text-[9px] uppercase tracking-wider">{card.status}</span>
                          </div>
                          <p className="font-bold text-[#0F172A] uppercase tracking-tight line-clamp-2 mb-2.5 leading-tight">{card.title}</p>
                          <div className="flex justify-between items-center pt-2.5 border-t border-slate-100 text-[10px]">
                            <span className="text-slate-400 font-medium">Exam: <span className="font-bold text-slate-700">{card.examDate}</span></span>
                            <a href={card.downloadUrl} target="_blank" rel="noreferrer" className="text-[#2563EB] hover:text-blue-700 font-extrabold uppercase tracking-wider underline">
                              Download PDF
                            </a>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Results Alerts */}
                  <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                    <h3 className="text-base font-black font-display text-slate-900 uppercase tracking-tight border-b border-slate-100 pb-3 mb-4 flex items-center space-x-2">
                      <span className="w-1.5 h-4.5 bg-emerald-500 rounded-full inline-block"></span>
                      <span>Exam Outcomes</span>
                    </h3>
                    <div className="space-y-3.5">
                      {results.map(res => (
                        <div key={res.id} className="p-4 bg-slate-50/60 rounded-2xl border border-slate-100 hover:bg-white transition text-xs">
                          <div className="flex justify-between items-center mb-1.5">
                            <span className="text-[#2563EB] font-bold uppercase text-[9px] font-mono tracking-wider">{res.category}</span>
                            <span className="text-[9px] text-slate-400 font-mono font-bold leading-none">{res.declareDate}</span>
                          </div>
                          <p className="font-bold text-[#0F172A] uppercase tracking-tight line-clamp-2 mb-2.5 leading-tight">{res.title}</p>
                          <div className="pt-2.5 border-t border-slate-100 flex justify-between items-center">
                            <span className="text-[10px] text-slate-400 font-bold uppercase">Officially Verified</span>
                            <a href={res.resultUrl} target="_blank" rel="noreferrer" className="text-emerald-600 hover:text-emerald-700 font-extrabold uppercase tracking-wider underline text-[10px]">
                              View Outcome
                            </a>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>

              </div>

              {/* Sidebar Column */}
              <div className="lg:col-span-4 space-y-6">
                


                {/* Popular Mock Tests Shortcut Widget */}
                <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                  <h3 className="text-xs font-black uppercase text-slate-400 tracking-widest mb-4 flex items-center space-x-1.5">
                    <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                    <span>POPULAR MOCK EXAMS</span>
                  </h3>
                  <div className="space-y-3.5">
                    {mockTests.slice(0, 3).map(test => (
                      <div key={test.id} className="p-4 bg-slate-50/60 rounded-2xl border border-slate-100 hover:bg-white transition duration-200">
                        <div className="flex justify-between items-center mb-1.5">
                          <span className="text-[10px] font-bold uppercase text-[#2563EB] font-mono">{test.category}</span>
                          <span className={`text-[9px] font-black px-2 py-0.5 rounded-md ${test.isPaid ? 'bg-amber-50 text-amber-700 border border-amber-200' : 'bg-emerald-50 text-emerald-800 border border-emerald-100'}`}>
                            {test.isPaid ? 'PREMIUM' : 'FREE'}
                          </span>
                        </div>
                        <p className="text-sm font-bold text-[#0F172A] uppercase tracking-tight line-clamp-1">{test.title}</p>
                        <div className="flex justify-between items-center mt-3 pt-2.5 border-t border-slate-100 text-xs font-medium text-slate-500">
                          <span>{test.totalQuestions} GK/QA Questions</span>
                          <button 
                            onClick={() => startExam(test)}
                            className="text-[#2563EB] hover:text-blue-700 font-extrabold flex items-center space-x-1"
                          >
                            <span>Start Test</span>
                            <Play className="w-3 h-3 fill-current" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Join Telegram Channel Banner */}
                <div className="bg-gradient-to-br from-indigo-50/40 via-sky-50 to-blue-50/20 border border-sky-100 p-6 rounded-3xl text-center">
                  <p className="text-sky-800 text-lg font-black font-display uppercase tracking-tight mb-1">✈️ Telegram Alerts</p>
                  <p className="text-slate-600 text-[11px] font-medium leading-relaxed mb-4">
                    Get instant smartphone alerts and official vetted PDF documents instantly.
                  </p>
                  <a 
                    href="https://t.me/examduniya_alerts" 
                    target="_blank" 
                    rel="noreferrer" 
                    className="block w-full py-3 bg-[#24A1DE] hover:bg-[#208ebe] text-white rounded-xl font-bold text-xs uppercase tracking-wider shadow-md hover:shadow-lg transition duration-200"
                  >
                    Join Channel
                  </a>
                </div>

              </div>

            </div>

          </div>
        )}

        {/* DETAILED RECRUITMENT JOB ALERT MODAL / DETAILED BLOCK */}
        {selectedJob && (
          <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 flex flex-col">
              
              {/* Header */}
              <div className="p-6 border-b border-slate-100 flex justify-between items-start sticky top-0 bg-white z-10">
                <div>
                  <span className="bg-[#2563EB]/10 text-[#2563EB] text-xs px-3 py-1 rounded-full font-black uppercase tracking-wider">
                    Official recruitment notify: {selectedJob.category}
                  </span>
                  <h3 className="text-2xl font-black text-[#0F172A] mt-2 leading-tight uppercase">
                    {selectedJob.title}
                  </h3>
                </div>
                <button 
                  onClick={() => setSelectedJob(null)}
                  className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-500 rounded-full transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Body */}
              <div className="p-6 space-y-6">
                
                {/* Meta details grid */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100 text-xs font-semibold">
                  <div>
                    <span className="text-slate-400 block">Category/Dep</span>
                    <strong className="text-slate-900 font-black">{selectedJob.category}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Post Count</span>
                    <strong className="text-slate-900 font-bold">{selectedJob.postCount} Open Vacancies</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Last Date Apply</span>
                    <strong className="text-slate-900 font-bold text-red-500">{selectedJob.lastDateToApply}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Proposed Exam Date</span>
                    <strong className="text-[#2563EB] font-bold">{selectedJob.examDate || 'Refer Pdf'}</strong>
                  </div>
                </div>

                {/* Additional criteria block */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-bold text-slate-700">
                  <div className="p-3.5 bg-slate-50 border rounded-xl">
                    <span className="text-slate-400 block text-[10px] uppercase">Age Constraints</span>
                    {selectedJob.ageLimit}
                  </div>
                  <div className="p-3.5 bg-slate-50 border rounded-xl">
                    <span className="text-slate-400 block text-[10px] uppercase">Qualifications</span>
                    {selectedJob.qualification}
                  </div>
                  <div className="p-3.5 bg-slate-50 border rounded-xl">
                    <span className="text-slate-400 block text-[10px] uppercase">Application Fee</span>
                    {selectedJob.applicationFee}
                  </div>
                </div>

                {/* Raw content briefing */}
                <div className="prose text-sm text-slate-700 leading-relaxed max-w-none">
                  <h4 className="font-black text-[#0F172A] uppercase tracking-tight text-xs mb-2">Notice summary guidelines:</h4>
                  <div className="whitespace-pre-line bg-slate-50 p-4 rounded-xl border font-sans text-xs">
                    {selectedJob.details}
                  </div>
                </div>

                {/* Standard affiliate disclaimer */}
                <div className="p-4 bg-amber-50 rounded-2xl border border-amber-150 text-[11px] text-amber-800 font-medium">
                  <strong>DISCLAIMER NOTICE</strong>: ExamDuniya represents a completely independent community bulletin page. We are in no shape or form authorized directly by parent departments. Please check official portals before locking inputs.
                </div>

              </div>

              {/* Footer CTAs */}
              <div className="p-6 border-t border-slate-100 flex flex-wrap gap-2 justify-end bg-slate-50 rounded-b-3xl">
                <a href={selectedJob.pdfUrl} target="_blank" rel="noreferrer" className="px-5 py-3 bg-slate-200 hover:bg-slate-300 text-slate-800 font-black text-xs uppercase rounded-xl tracking-wider">
                  Read Notification PDF
                </a>
                <a href={selectedJob.applyUrl} target="_blank" rel="noreferrer" className="px-5 py-3 bg-[#2563EB] hover:bg-blue-600 text-white font-black text-xs uppercase rounded-xl tracking-wider shadow">
                  Apply Online Direct Link
                </a>
              </div>

            </div>
          </div>
        )}

        {/* MOCK TESTS VIEW */}
        {currentTab === 'mocktests' && (
          <div>
            <div className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h2 className="text-3xl font-black font-display text-slate-900 tracking-tight uppercase">
                  Adaptive Mock Assessments
                </h2>
                <p className="text-slate-500 font-semibold text-xs mt-1">
                  Practise verified interactive exam sets corresponding to live state syllabus.
                </p>
              </div>

              {/* Selector */}
              <div className="flex items-center space-x-2 bg-white px-4 py-2.5 rounded-xl border border-slate-200 shadow-sm">
                <span className="text-xs text-slate-400 font-bold uppercase tracking-wider font-mono">Category:</span>
                <select 
                  value={selectedCategory} 
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="bg-transparent border-none text-xs font-black text-slate-900 focus:outline-none cursor-pointer"
                >
                  <option value="All">🌐 All Packages</option>
                  <option value="SSC">SSC Exams</option>
                  <option value="UP Police">UP Police Sets</option>
                  <option value="Railway">Railway Group C/D</option>
                </select>
              </div>
            </div>

            {/* Mock Test listing board */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredMockTests.map(test => {
                const cleanCat = test.category.toLowerCase().replace(/[^a-z]/g, '');
                const hasSub = subscriptions.some(s => s.packId === cleanCat || s.packId === 'all-combo');
                const isLocked = test.isPaid && !hasSub;

                return (
                  <div key={test.id} className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 hover:border-slate-200 hover:shadow-lg transition flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-center mb-3">
                        <span className="bg-blue-50 text-[#2563EB] border border-blue-100 text-[9px] px-3 py-1 rounded-lg font-mono font-bold uppercase tracking-wider">
                          {test.category}
                        </span>
                        <span className={`text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-full ${test.isPaid ? 'bg-amber-500/10 text-amber-700 border border-amber-200/50' : 'bg-emerald-50 text-emerald-700 border border-emerald-100'}`}>
                          {test.isPaid ? '⭐ Locked Premium' : 'Free Demo'}
                        </span>
                      </div>

                      <h3 className="text-lg font-black font-display text-slate-900 leading-snug uppercase tracking-tight">
                        {test.title}
                      </h3>

                      <div className="grid grid-cols-3 gap-2 py-4 text-center text-xs font-bold border-y border-slate-100 my-4 text-slate-600">
                        <div>
                          <span className="text-slate-400 block text-[9px] uppercase font-mono mb-0.5">Questions</span>
                          <strong className="text-slate-800">{test.totalQuestions} GK/QA</strong>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[9px] uppercase font-mono mb-0.5">Timer</span>
                          <strong className="text-slate-800">{test.durationMinutes} min</strong>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[9px] uppercase font-mono mb-0.5">Weights</span>
                          <strong className="text-slate-800">+{test.scoreWeight} / -{test.negativeMarks}</strong>
                        </div>
                      </div>
                    </div>

                    <div className="mt-2">
                      {isLocked ? (
                        <button 
                          onClick={() => {
                            triggerToast("Subscription Required! Moving to Pricing page.");
                            setCurrentTab('subscription');
                          }}
                          className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs uppercase rounded-xl flex items-center justify-center space-x-2 shadow-md"
                        >
                          <Lock className="w-3.5 h-3.5" />
                          <span>Unlock With Pass</span>
                        </button>
                      ) : (
                        <button 
                          onClick={() => startExam(test)}
                          className="w-full py-3 bg-[#0F172A] hover:bg-slate-800 text-white font-black text-xs uppercase rounded-xl flex items-center justify-center space-x-2 tracking-wider shadow"
                        >
                          <Play className="w-3.5 h-3.5 text-[#F59E0B]" />
                          <span>Start Live Test</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Performance analytics leaderboard section */}
            <div className="mt-12 bg-white rounded-3xl p-6 md:p-8 shadow-sm border border-slate-100">
              <h3 className="text-xl font-black font-display text-slate-900 uppercase tracking-tight border-b border-slate-100 pb-4 mb-4 flex items-center space-x-2">
                <span className="w-1.5 h-6 bg-amber-500 rounded-full inline-block"></span>
                <span>Candidate Performance Leaderboard</span>
              </h3>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-bold text-slate-700">
                  <thead>
                    <tr className="border-b border-slate-100 text-slate-400 text-[10px] uppercase font-mono">
                      <th className="py-2.5">Global Rank</th>
                      <th>Candidate Name</th>
                      <th>Mock Count</th>
                      <th>Avg Marks</th>
                      <th className="text-right">Aptitude Score</th>
                    </tr>
                  </thead>
                  <tbody>
                    {leaderboard.map((item, index) => (
                      <tr key={index} className="border-b border-slate-100 last:border-none py-2 hover:bg-slate-50 transition duration-150">
                        <td className="py-3">
                          <span className={`w-6 h-6 rounded-lg flex items-center justify-center font-black text-[11px] ${
                            item.rank === 1 ? 'bg-amber-500 text-slate-950 shadow' : 
                            item.rank === 2 ? 'bg-slate-300 text-slate-950' :
                            item.rank === 3 ? 'bg-amber-600/20 text-amber-900' : 'bg-slate-100 text-slate-500'
                          }`}>
                            #{item.rank}
                          </span>
                        </td>
                        <td className="font-extrabold text-[#0F172A] uppercase">{item.name}</td>
                        <td className="text-slate-500 font-normal">{item.testsAttempted} sessions</td>
                        <td className="text-slate-700">{item.averageScore} / 10 marks</td>
                        <td className="text-right text-blue-600 font-extrabold font-mono">{item.totalPoints} pts</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* CURRENT AFFAIRS VIEW */}
        {currentTab === 'currentaffairs' && (
          <div>
            <div className="mb-6">
              <h2 className="text-3xl font-black text-[#0F172A] tracking-tight uppercase">
                Direct Current Affairs Updates (2026)
              </h2>
              <p className="text-slate-500 font-semibold text-xs mt-1">
                Factual briefing, structural policies, and daily bulletins crucial for competitive examinations.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {currentAffairs.map(ca => (
                <div key={ca.id} className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200 hover:shadow-lg transition flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center mb-3">
                      <span className="bg-[#22C55E]/10 text-[#22C55E] text-[10px] px-3 py-1 rounded-md font-black uppercase tracking-wider">
                        {ca.category}
                      </span>
                      <span className="text-xs text-slate-400 font-bold">{ca.date}</span>
                    </div>

                    <h3 className="text-base font-black text-[#0F172A] mb-3 leading-snug">
                      {ca.title}
                    </h3>
                    
                    <div className="prose text-xs text-slate-600 leading-relaxed font-semibold whitespace-pre-line bg-slate-50 p-4 rounded-xl border border-slate-200 mb-4 h-48 overflow-y-auto">
                      {ca.content}
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-100">
                    {ca.tags.map(tag => (
                      <span key={tag} className="text-[10px] bg-slate-100 text-slate-600 px-2.5 py-1 rounded font-black uppercase">
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SUBSCRIPTION BUY PORTAL */}
        {currentTab === 'subscription' && (
          <div>
            <div className="text-center max-w-2xl mx-auto mb-10 bg-slate-50 rounded-2xl p-6 border border-slate-100">
              <span className="bg-amber-50 text-amber-700 text-[10px] font-mono font-bold px-4 py-1.5 rounded-full uppercase tracking-widest border border-amber-200/50">
                ⭐ Premium Access Passes
              </span>
              <h2 className="text-3xl font-black font-display text-slate-900 tracking-tight mt-3 uppercase">
                EXAM PASSES & VIP COMBO
              </h2>
              <p className="text-slate-500 font-medium text-xs mt-1.5 leading-relaxed">
                Attempt premium high accuracy exam questions with zero limits! Cancel anytime. Secured via PayU Payment Gateways sandbox environments.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              
              {/* UP Police pack */}
              <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 flex flex-col justify-between relative hover:border-blue-500 hover:shadow-xl transition-all duration-300">
                <div>
                  <h3 className="text-lg font-black font-display text-[#0F172A] uppercase">UP Police Premium</h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">Constables, SI & Computer operators</p>
                  
                  <div className="text-4xl font-black font-display text-[#0F172A] my-6">
                    ₹299 <span className="text-xs text-slate-400 font-semibold font-sans">/ 1-Yr Lizenz</span>
                  </div>

                  <ul className="text-xs font-medium text-slate-600 space-y-3.5 border-t border-slate-100 pt-5 my-6">
                    <li className="flex items-center space-x-2.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span>150+ Full size sets with Explanations</span>
                    </li>
                    <li className="flex items-center space-x-2.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span>Daily mock current affairs test access</span>
                    </li>
                  </ul>
                </div>

                <button 
                  onClick={() => buySubscription('up-police', 299)}
                  className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs uppercase rounded-xl tracking-wider shadow hover:-translate-y-0.5 transition duration-200"
                >
                  Unlock Pass with PayU
                </button>
              </div>

              {/* SSC Mastery */}
              <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 flex flex-col justify-between relative hover:border-blue-500 hover:shadow-xl transition-all duration-300">
                <div>
                  <h3 className="text-lg font-black font-display text-[#0F172A] uppercase">SSC Mastery Pack</h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">CGL, CHSL, MTS & GD Constables</p>
                  
                  <div className="text-4xl font-black font-display text-[#0F172A] my-6">
                    ₹399 <span className="text-xs text-slate-400 font-semibold font-sans">/ 1-Yr Lizenz</span>
                  </div>

                  <ul className="text-xs font-medium text-slate-600 space-y-3.5 border-t border-slate-100 pt-5 my-6">
                    <li className="flex items-center space-x-2.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span>350+ mock sheets under new syllabus</span>
                    </li>
                    <li className="flex items-center space-x-2.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span>AI analytics score checker integrated</span>
                    </li>
                  </ul>
                </div>

                <button 
                  onClick={() => buySubscription('ssc-gd', 399)}
                  className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs uppercase rounded-xl tracking-wider shadow hover:-translate-y-0.5 transition duration-200"
                >
                  Unlock Pass with PayU
                </button>
              </div>

              {/* Super combo */}
              <div className="bg-[#090D1A] text-white rounded-3xl p-6 shadow-xl border border-slate-800 flex flex-col justify-between relative bg-[radial-gradient(ellipse_100%_100%_at_50%_-20%,rgba(245,158,11,0.15),transparent)]">
                <span className="absolute top-4 right-4 bg-amber-500 text-slate-950 text-[9px] px-2.5 py-1 rounded font-mono font-bold uppercase tracking-widest">
                  VIP COMBO
                </span>

                <div>
                  <h3 className="text-lg font-black font-display text-amber-500 uppercase">Premium VIP Combo</h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">All Police, SSC, Railways, State PCS Exams</p>
                  
                  <div className="text-4xl font-black font-display text-white my-6">
                    ₹599 <span className="text-xs text-slate-400 font-semibold font-sans">/ Lifetime access</span>
                  </div>

                  <ul className="text-xs font-medium text-slate-300 space-y-3.5 border-t border-slate-800 pt-5 my-6">
                    <li className="flex items-center space-x-2.5">
                      <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0" />
                      <span>Complete unlock of all mock database series</span>
                    </li>
                    <li className="flex items-center space-x-2.5">
                      <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0" />
                      <span>Free priority developer AI generators usage</span>
                    </li>
                  </ul>
                </div>

                <button 
                  onClick={() => buySubscription('all-combo', 599)}
                  className="w-full py-3 bg-amber-500 text-slate-950 font-extrabold text-xs uppercase rounded-xl tracking-wider hover:bg-amber-400 hover:-translate-y-0.5 transition-all duration-200 shadow-lg shadow-amber-950/20"
                >
                  Unlock Ultimate Pass ₹599
                </button>
              </div>

            </div>
          </div>
        )}

        {/* RECRUITMENT PROFILE SECTION */}
        {currentTab === 'profile' && user && (
          <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-200">
            <h2 className="text-2xl font-black text-[#0F172A] uppercase border-b pb-4 mb-6 tracking-tight">
              Aspirant Workspace Account Dashboard
            </h2>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* Credentials / Avatar */}
              <div className="bg-slate-50 p-6 rounded-2xl border text-center">
                <div className="w-20 h-20 bg-[#2563EB] text-white flex items-center justify-center text-4xl font-extrabold rounded-full mx-auto mb-4 tracking-tighter shadow-lg">
                  {user.name.charAt(0)}
                </div>
                <strong className="text-lg font-black block text-slate-900 uppercase">{user.name}</strong>
                <span className="text-xs text-slate-500 font-bold block mt-1">{user.email}</span>
                
                <span className="inline-block mt-4 text-[10px] uppercase font-black tracking-widest bg-slate-900 text-[#F59E0B] px-3.5 py-1.5 rounded-full border border-slate-700">
                  Authentication: {user.role.toUpperCase()}
                </span>
              </div>

              {/* Active Packages unlocked */}
              <div className="lg:col-span-2 space-y-4">
                <h3 className="text-sm font-black uppercase text-slate-400 tracking-widest">
                  Unveiled Subscription Licences
                </h3>

                {subscriptions.length === 0 ? (
                  <div className="p-5 bg-amber-50 border border-amber-100 rounded-2xl text-xs text-amber-800 font-bold">
                    You have not subscribed to any exam series plans yet. Attempts are limited to demo tests. Use the Packages panel to join premium sets!
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {subscriptions.map(sub => (
                      <div key={sub.id} className="p-4 bg-[#0F172A] text-white rounded-2xl border border-slate-800">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-[10px] uppercase font-black text-[#F59E0B]">{sub.packName}</span>
                          <span className="text-[9px] font-bold text-[#22C55E]">● Active</span>
                        </div>
                        <p className="text-xs text-slate-400 font-semibold">Unlocked cost: ₹{sub.amount}</p>
                        <p className="text-[10px] text-slate-400 font-bold mt-2">Expires: {sub.expiryDate}</p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Score Log History */}
                <h3 className="text-sm font-black uppercase text-slate-400 tracking-widest pt-4">
                  Past Mock Score History logs
                </h3>

                {attempts.length === 0 ? (
                  <p className="text-xs text-slate-500 font-bold bg-slate-50 p-4 rounded-xl text-center">No tests attempted till now.</p>
                ) : (
                  <div className="space-y-3">
                    {attempts.map(att => (
                      <div key={att.id} className="p-4 bg-slate-50 rounded-2xl border flex justify-between items-center text-xs">
                        <div>
                          <strong className="text-slate-900 block font-black text-sm">{att.mockTestTitle}</strong>
                          <span className="text-slate-400 block mt-0.5">Attempted date: {new Date(att.createdAt).toLocaleDateString()}</span>
                        </div>
                        <div className="text-right">
                          <strong className="text-lg font-black text-[#2563EB] block">{att.score} marks</strong>
                          <span className="text-[#0F172A]/50 font-bold text-[10px]">Rank #{att.rank} / {att.totalParticipants}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

              </div>

            </div>
          </div>
        )}

        {/* CENTRAL ADMINISTRATOR CONTROL TAB */}
        {currentTab === 'admin' && (user?.role === 'admin' || user?.role === 'developer') && (
          <div className="space-y-8" id="admin-management-view">
            
            {/* Quick Sandbox Switcher within Admin Panel */}
            <div className="bg-slate-900 text-white rounded-3xl p-6 border border-slate-800 shadow-lg flex flex-col md:flex-row justify-between items-center gap-4">
              <div>
                <h4 className="text-sm font-black uppercase text-violet-400 tracking-wider">⚡ Admin Role Switcher</h4>
                <p className="text-xs text-slate-400 mt-1">Directly hot-swap between logged-in test credentials inside the sandbox environment.</p>
              </div>
              <div className="flex gap-2 flex-wrap">
                <button 
                  onClick={() => quickLogin('developer')} 
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-xs font-black transition shadow-sm"
                >
                  🔒 VIP Developer
                </button>
                <button 
                  onClick={() => quickLogin('admin')} 
                  className="bg-violet-600 hover:bg-violet-700 text-white px-4 py-2 rounded-xl text-xs font-black transition shadow-sm"
                >
                  🛡️ Admin Portal
                </button>
                <button 
                  onClick={() => quickLogin('user')} 
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-black transition shadow-sm"
                >
                  Student Account
                </button>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200">
              <h2 className="text-2xl font-black text-[#0F172A] uppercase tracking-tight pb-3 border-b mb-6 flex items-center space-x-2">
                <span>🔧</span>
                <span>Upload Recruitment alert Notification</span>
              </h2>

              <form onSubmit={submitNewJobAlert} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black uppercase text-slate-400 mb-1">Recruitment Title</label>
                  <input 
                    type="text" 
                    required
                    value={newJobType.title}
                    onChange={(e) => setNewJobType({...newJobType, title: e.target.value})}
                    placeholder="e.g. SSC GD Force Constable Notification 2026"
                    className="w-full text-xs p-3 rounded-lg border bg-slate-50 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-400 mb-1">State Department</label>
                  <input 
                    type="text" 
                    required
                    value={newJobType.department}
                    onChange={(e) => setNewJobType({...newJobType, department: e.target.value})}
                    placeholder="e.g. Staff Selection Commission"
                    className="w-full text-xs p-3 rounded-lg border bg-slate-50 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-400 mb-1">Department Category</label>
                  <select 
                    value={newJobType.category}
                    onChange={(e) => setNewJobType({...newJobType, category: e.target.value})}
                    className="w-full text-xs p-3 rounded-lg border bg-slate-50 focus:outline-none"
                  >
                    <option value="SSC">SSC</option>
                    <option value="UP Police">UP Police</option>
                    <option value="Railway">Railway</option>
                    <option value="UPSC">UPSC</option>
                    <option value="UPSSSC">UPSSSC</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-400 mb-1">Post Count (Vacancies)</label>
                  <input 
                    type="number" 
                    value={newJobType.postCount}
                    onChange={(e) => setNewJobType({...newJobType, postCount: parseInt(e.target.value) || 0})}
                    className="w-full text-xs p-3 rounded-lg border bg-slate-50 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-400 mb-1">Age Limits criteria</label>
                  <input 
                    type="text" 
                    value={newJobType.ageLimit}
                    onChange={(e) => setNewJobType({...newJobType, ageLimit: e.target.value})}
                    className="w-full text-xs p-3 rounded-lg border bg-slate-50 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-400 mb-1">Qualification description</label>
                  <input 
                    type="text" 
                    value={newJobType.qualification}
                    onChange={(e) => setNewJobType({...newJobType, qualification: e.target.value})}
                    className="w-full text-xs p-3 rounded-lg border bg-slate-50 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-400 mb-1">Notification PDF Direct Link</label>
                  <input 
                    type="text" 
                    value={newJobType.pdfUrl}
                    onChange={(e) => setNewJobType({...newJobType, pdfUrl: e.target.value})}
                    placeholder="e.g. https://example.com/notification.pdf"
                    className="w-full text-xs p-3 rounded-lg border bg-slate-50 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-400 mb-1">Online Direct Apply Link</label>
                  <input 
                    type="text" 
                    value={newJobType.applyUrl}
                    onChange={(e) => setNewJobType({...newJobType, applyUrl: e.target.value})}
                    placeholder="e.g. https://example.com/apply-online"
                    className="w-full text-xs p-3 rounded-lg border bg-slate-50 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-400 mb-1">Official Website URL Link</label>
                  <input 
                    type="text" 
                    value={newJobType.officialWebsite}
                    onChange={(e) => setNewJobType({...newJobType, officialWebsite: e.target.value})}
                    placeholder="e.g. https://example.gov.in"
                    className="w-full text-xs p-3 rounded-lg border bg-slate-50 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-400 mb-1">Last Date to Apply</label>
                  <input 
                    type="text" 
                    value={newJobType.lastDateToApply}
                    onChange={(e) => setNewJobType({...newJobType, lastDateToApply: e.target.value})}
                    placeholder="e.g. 2026-07-31"
                    className="w-full text-xs p-3 rounded-lg border bg-slate-50 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-400 mb-1">Proposed Exam Date</label>
                  <input 
                    type="text" 
                    value={newJobType.examDate}
                    onChange={(e) => setNewJobType({...newJobType, examDate: e.target.value})}
                    placeholder="e.g. 2026-09-10"
                    className="w-full text-xs p-3 rounded-lg border bg-slate-50 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-400 mb-1">Application Fee Detail</label>
                  <input 
                    type="text" 
                    value={newJobType.applicationFee}
                    onChange={(e) => setNewJobType({...newJobType, applicationFee: e.target.value})}
                    placeholder="e.g. ₹100 for General/OBC"
                    className="w-full text-xs p-3 rounded-lg border bg-slate-50 focus:outline-none"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-black uppercase text-slate-400 mb-1">Details & Syllabus Breakdown information</label>
                  <textarea 
                    rows={4}
                    required
                    value={newJobType.details}
                    onChange={(e) => setNewJobType({...newJobType, details: e.target.value})}
                    placeholder="Enter physical tests criteria, syllabus weights, and stages of filtering standard exams..."
                    className="w-full text-xs p-3 rounded-lg border bg-slate-50 focus:outline-none font-mono"
                  ></textarea>
                </div>

                <div className="md:col-span-2 text-right">
                  <button 
                    type="submit"
                    className="px-6 py-3 bg-[#0F172A] text-white text-xs font-black uppercase rounded-lg tracking-wider hover:bg-slate-800 transition"
                  >
                    Publish Notification Alert
                  </button>
                </div>
              </form>
            </div>

            {/* List and manage dynamic items */}
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200">
              <h3 className="text-lg font-black text-[#0F172A] uppercase pb-3 mb-4 border-b">
                Vetted notifications on database live and ready
              </h3>
              <div className="space-y-3">
                {jobs.map(job => (
                  <div key={job.id} className="p-4 bg-slate-50 rounded-xl border flex justify-between items-center text-xs">
                    <div>
                      <span className="text-slate-400 font-bold block font-mono">{job.id} • {job.category}</span>
                      <strong className="text-[#0F172A] font-extrabold">{job.title}</strong>
                    </div>
                    
                    <button 
                      onClick={async () => {
                        if (confirm(`Do you want to delete job alert ID: ${job.id}?`)) {
                          const res = await fetch(`/api/jobs/${job.id}`, {
                            method: 'DELETE',
                            headers: { 'Authorization': `Bearer ${token}` }
                          });
                          if (res.ok) {
                            triggerToast("Cleared successfully.");
                            fetchPublicData();
                          }
                        }
                      }}
                      className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                      title="Delete notification"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* DEVELOPER CONSOLE CONTROL PANEL */}
        {currentTab === 'developer' && user?.role === 'developer' && (
          <div className="space-y-8" id="dev-console-view">
            
            {/* Developer/Evaluator Quick Switcher inside Dev Panel */}
            <div className="bg-slate-900 text-white rounded-3xl p-6 border border-slate-800 shadow-lg flex flex-col md:flex-row justify-between items-center gap-4">
              <div>
                <h4 className="text-sm font-black uppercase text-green-400 tracking-wider">⚡ Developer Quick Switcher</h4>
                <p className="text-xs text-slate-400 mt-1">Directly hot-swap between test logins inside the sandbox environment.</p>
              </div>
              <div className="flex gap-2 flex-wrap">
                <button 
                  onClick={() => quickLogin('developer')} 
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-xs font-black transition shadow-sm"
                >
                  🔒 VIP Developer
                </button>
                <button 
                  onClick={() => quickLogin('admin')} 
                  className="bg-violet-600 hover:bg-violet-700 text-white px-4 py-2 rounded-xl text-xs font-black transition shadow-sm"
                >
                  🛡️ Admin Portal
                </button>
                <button 
                  onClick={() => quickLogin('user')} 
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-black transition shadow-sm"
                >
                  Student Account
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              
              {/* Gemini Models AI Generator */}
              <div className="bg-gradient-to-r from-[#0F172A] to-[#1E293B] text-white rounded-3xl p-6 shadow-xl border border-slate-800">
                <div className="flex items-center space-x-2 mb-4">
                  <Cpu className="text-[#F59E0B] w-6 h-6" />
                  <h3 className="text-xl font-black uppercase text-[#F59E0B]">AI Mock Test Generator (Gemini Keyed)</h3>
                </div>

                <p className="text-xs text-slate-300 font-semibold mb-6">
                  Compose dynamic simulated question arrays through real-time Gemini processing models. Mapped directly onto database on successful compilation.
                </p>

                <form onSubmit={generateAIMockTest} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-400 mb-1">Primary Target Exam Group</label>
                    <select 
                      value={aiExamName}
                      onChange={(e) => setAiExamName(e.target.value)}
                      className="w-full text-xs p-3 rounded-lg bg-slate-800 border border-slate-700 text-white focus:outline-none"
                    >
                      <option value="SSC">SSC Board Exams</option>
                      <option value="UP Police">UP State Police Constable</option>
                      <option value="Railway">Indian Railways (NTPC/Group D)</option>
                      <option value="UPSC">UPSC Civil Services Prelims</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-black uppercase text-slate-400 mb-1">Subject domain</label>
                      <input 
                        type="text" 
                        required
                        value={aiSubject}
                        onChange={(e) => setAiSubject(e.target.value)}
                        placeholder="e.g. Indian Polity"
                        className="w-full text-xs p-3 rounded-lg bg-slate-800 border border-slate-700 text-white focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black uppercase text-slate-400 mb-1">Topic details</label>
                      <input 
                        type="text" 
                        required
                        value={aiTopic}
                        onChange={(e) => setAiTopic(e.target.value)}
                        placeholder="e.g. Fundamental Rights"
                        className="w-full text-xs p-3 rounded-lg bg-slate-800 border border-slate-700 text-white focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-black uppercase text-slate-400 mb-1">Difficulty</label>
                      <select 
                        value={aiDifficulty}
                        onChange={(e) => setAiDifficulty(e.target.value as any)}
                        className="w-full text-xs p-3 rounded-lg bg-slate-800 border border-slate-700 text-white focus:outline-none"
                      >
                        <option value="Easy">Easy</option>
                        <option value="Medium">Medium</option>
                        <option value="Hard">Hard</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-black uppercase text-slate-400 mb-1">Quantity</label>
                      <input 
                        type="number" 
                        value={aiQuantity}
                        onChange={(e) => setAiQuantity(parseInt(e.target.value) || 5)}
                        className="w-full text-xs p-3 rounded-lg bg-slate-800 border border-slate-700 text-white focus:outline-none"
                      />
                    </div>
                  </div>

                  {aiSuccessMessage && (
                    <div className="p-3 bg-green-950/40 text-green-300 rounded-lg text-xs font-bold border border-green-800">
                      {aiSuccessMessage}
                    </div>
                  )}

                  <button 
                    type="submit"
                    disabled={aiGenerating}
                    className="w-full py-3 bg-[#F59E0B] text-slate-950 font-black text-xs uppercase rounded-xl tracking-widest hover:bg-amber-400 transition"
                  >
                    {aiGenerating ? 'AI model formulating questions...' : 'Generate New Mock Test via Gemini'}
                  </button>
                </form>
              </div>

              {/* AI Current Affairs generated */}
              <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Star className="text-indigo-600 w-6 h-6" />
                  <h3 className="text-xl font-black uppercase tracking-tight text-slate-900">AI Daily news update publisher</h3>
                </div>

                <p className="text-xs text-slate-500 font-semibold mb-6">
                  Compile comprehensive daily brief insights by passing search topics across the model.
                </p>

                <form onSubmit={generateAICurrentAffairs} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-500 mb-1">Topic news query</label>
                    <input 
                      type="text" 
                      required
                      value={aiCaTopic}
                      onChange={(e) => setAiCaTopic(e.target.value)}
                      placeholder="e.g. G20 Summit Agenda 2026 Climate rules"
                      className="w-full text-xs p-3 rounded-lg border bg-slate-50 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-500 mb-1">Syllabus Tag Category</label>
                    <select 
                      value={aiCaCategory}
                      onChange={(e) => setAiCaCategory(e.target.value)}
                      className="w-full text-xs p-3 rounded-lg border bg-slate-50 focus:outline-none"
                    >
                      <option value="National">National Governance</option>
                      <option value="Economy">Economy & Infrastructure</option>
                      <option value="Science & Technology">Science & Technology</option>
                      <option value="International">International relations</option>
                    </select>
                  </div>

                  <button 
                    type="submit"
                    disabled={aiCaGenerating}
                    className="w-full py-3 bg-[#0F172A] text-white font-black text-xs uppercase rounded-xl tracking-widest hover:bg-slate-800 transition"
                  >
                    {aiCaGenerating ? 'Formulating summary...' : 'Write daily update with AI'}
                  </button>
                </form>
              </div>

            </div>

            {/* System logs and controls */}
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200">
              <div className="flex justify-between items-center border-b pb-4 mb-4">
                <div>
                  <h3 className="text-lg font-black text-[#0F172A] uppercase">Active Platform System logs</h3>
                  <p className="text-xs text-slate-400 font-bold">Monitor authentication callbacks, API transactions, and errors.</p>
                </div>
                <button 
                  onClick={clearDevLogs}
                  className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-600 font-black rounded-lg text-xs uppercase"
                >
                  Clear logs
                </button>
              </div>

              {systemSettings && (
                <div className="mb-6 p-4 bg-slate-50 rounded-2xl border border-slate-200 grid grid-cols-2 lg:grid-cols-5 gap-4 text-xs font-bold text-slate-700">
                  <div>
                    <span className="text-slate-400 block">Active AI Model:</span>
                    <strong className="text-slate-900 font-bold">{systemSettings.geminiModel}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Google OAuth:</span>
                    <strong className="text-slate-900 font-bold">Enabled</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">PayU gateway:</span>
                    <strong className="text-slate-900 font-bold">Simulated active</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">SMTP state:</span>
                    <strong className="text-slate-900 font-bold">{systemSettings.smtpStatus}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Telegram Auto-Post:</span>
                    <strong className={`${systemSettings.telegramStatus === 'Configured' ? 'text-green-600' : 'text-slate-500'} font-bold`}>
                      {systemSettings.telegramStatus || 'Not Configured'}
                    </strong>
                  </div>
                </div>
              )}

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 h-72 overflow-y-auto font-mono text-slate-300 text-xs space-y-1.5 scrollbar-thin">
                {systemLogs.length === 0 ? (
                  <p className="text-slate-500 italic">No logs generated yet.</p>
                ) : (
                  systemLogs.map(log => (
                    <div key={log.id} className="border-b border-slate-900 pb-1.5 last:border-b-0">
                      <span className="text-slate-500 text-[10px] mr-2">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                      <span className={`px-2 py-0.5 rounded text-[9px] uppercase font-bold mr-2 ${
                        log.type === 'error' ? 'bg-red-950/80 text-red-400' :
                        log.type === 'auth' ? 'bg-indigo-950/80 text-indigo-400' :
                        log.type === 'api' ? 'bg-amber-950/80 text-amber-400' : 'bg-slate-800 text-slate-300'
                      }`}>
                        {log.type}
                      </span>
                      <span>{log.message}</span>
                    </div>
                  ))
                )}
              </div>
            </div>

          </div>
        )}
          </>
        )}

      </main>

      {/* MODAL USER REGISTER & LOGIN */}
      {showAuthModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 md:p-8 shadow-2xl border border-slate-100/80 animate-in fade-in zoom-in-95 duration-200">
            
            <div className="flex justify-between items-center border-b border-slate-100 pb-4 mb-5">
              <h3 className="text-lg font-black font-display text-slate-900 uppercase tracking-tight">
                {forgotStep === 'request' ? 'Recover Passphrase' : 
                 forgotStep === 'reset' ? 'Set New Passphrase' :
                 isRegistering ? 'Enroll Account' : 'Aspirant Log In'}
              </h3>
              <button 
                onClick={() => { setShowAuthModal(false); setForgotStep(null); setAuthError(''); setForgotSuccessMessage(''); }} 
                className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-xl transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {forgotStep === 'request' ? (
              /* Recovery otp generation */
              <form onSubmit={handleForgotPasswordRequest} className="space-y-4">
                <p className="text-xs text-slate-500 leading-relaxed font-medium">
                  Enter your registered candidate email. If mapped in our system, we will generate a secure 6-digit confirmation OTP so you can securely reset your passphrase.
                </p>
                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 font-mono tracking-wider mb-1">Email address</label>
                  <input 
                    type="email" 
                    required
                    value={authEmail}
                    onChange={(e) => setAuthEmail(e.target.value)}
                    placeholder="e.g. rohan@example.com"
                    className="w-full text-xs p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 focus:outline-none focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-500/10 font-medium transition-all"
                  />
                </div>

                {authError && (
                  <p className="text-xs text-red-600 font-bold bg-red-50 p-2.5 rounded-xl border border-red-100 flex items-center space-x-2">
                    <span>⚠️</span>
                    <span>{authError}</span>
                  </p>
                )}

                <button 
                  type="submit"
                  className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs uppercase rounded-xl tracking-wider hover:-translate-y-0.5 active:translate-y-0 shadow-md hover:shadow-lg transition duration-200"
                >
                  Generate Recovery OTP
                </button>

                <div className="text-center pt-2">
                  <button 
                    type="button"
                    onClick={() => { setForgotStep(null); setAuthError(''); }} 
                    className="text-xs font-bold text-slate-500 hover:text-blue-600 transition hover:underline"
                  >
                    Back to Log In
                  </button>
                </div>
              </form>
            ) : forgotStep === 'reset' ? (
              /* Passphrase modification form */
              <form onSubmit={handleForgotPasswordReset} className="space-y-4">
                <div className="text-xs text-emerald-800 bg-emerald-50/90 p-3 rounded-xl border border-emerald-100 leading-relaxed font-semibold">
                  {forgotSuccessMessage || 'Forgot flow initiated. Check developer logs tab for transient code.'}
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 font-mono tracking-wider mb-1">Email address</label>
                  <input 
                    type="email" 
                    required
                    readOnly
                    value={authEmail}
                    className="w-full text-xs p-3.5 rounded-xl border border-slate-200 bg-slate-100 text-slate-500 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 font-mono tracking-wider mb-1">6-Digit Verification OTP</label>
                  <input 
                    type="text" 
                    required
                    maxLength={6}
                    placeholder="e.g. 123456"
                    value={forgotCode}
                    onChange={(e) => setForgotCode(e.target.value)}
                    className="w-full text-center text-lg font-black tracking-widest p-3 rounded-xl border border-slate-200 bg-slate-50/50 focus:outline-none focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-500/10 font-mono transition-all"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 font-mono tracking-wider mb-1">New Passphrase</label>
                  <input 
                    type="password" 
                    required
                    placeholder="Minimum 6 characters"
                    value={forgotNewPassword}
                    onChange={(e) => setForgotNewPassword(e.target.value)}
                    className="w-full text-xs p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 focus:outline-none focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-500/10 font-medium transition-all"
                  />
                </div>

                {authError && (
                  <p className="text-xs text-red-600 font-bold bg-red-50 p-2.5 rounded-xl border border-red-100 flex items-center space-x-2">
                    <span>⚠️</span>
                    <span>{authError}</span>
                  </p>
                )}

                <button 
                  type="submit"
                  className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs uppercase rounded-xl tracking-wider hover:-translate-y-0.5 active:translate-y-0 shadow-md hover:shadow-lg transition duration-200"
                >
                  Verify Code & Reset Password
                </button>

                <div className="text-center pt-2 flex justify-between">
                  <button 
                    type="button"
                    onClick={() => { setForgotStep('request'); setAuthError(''); }} 
                    className="text-xs font-bold text-slate-500 hover:text-slate-700 transition hover:underline"
                  >
                    Resend Code
                  </button>
                  <button 
                    type="button"
                    onClick={() => { setForgotStep(null); setAuthError(''); }} 
                    className="text-xs font-bold text-blue-600 hover:underline"
                  >
                    Back to Log In
                  </button>
                </div>
              </form>
            ) : (
              /* Standard LogIn & Enroll template */
              <>
                <form onSubmit={handleAuth} className="space-y-4">
                  {isRegistering && (
                    <div>
                      <label className="block text-[10px] font-bold uppercase text-slate-400 font-mono tracking-wider mb-1">Full candidate name</label>
                      <input 
                        type="text" 
                        required
                        value={authName}
                        onChange={(e) => setAuthName(e.target.value)}
                        placeholder="e.g. Rohan Sharma"
                        className="w-full text-xs p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 focus:outline-none focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-500/10 font-medium transition-all"
                      />
                    </div>
                  )}

                  <div>
                    <label className="block text-[10px] font-bold uppercase text-slate-400 font-mono tracking-wider mb-1">Email address</label>
                    <input 
                      type="email" 
                      required
                      value={authEmail}
                      onChange={(e) => setAuthEmail(e.target.value)}
                      placeholder="e.g. rohan@example.com"
                      className="w-full text-xs p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 focus:outline-none focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-500/10 font-medium transition-all"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="block text-[10px] font-bold uppercase text-slate-400 font-mono tracking-wider">Passphrase</label>
                      {!isRegistering && (
                        <button 
                          type="button" 
                          onClick={() => { setForgotStep('request'); setAuthError(''); }} 
                          className="text-[10px] font-bold text-blue-600 hover:text-blue-700 transition"
                        >
                          Forgot Password?
                        </button>
                      )}
                    </div>
                    <input 
                      type="password" 
                      required
                      value={authPassword}
                      onChange={(e) => setAuthPassword(e.target.value)}
                      placeholder="e.g. min 6 signs"
                      className="w-full text-xs p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 focus:outline-none focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-500/10 font-medium transition-all"
                    />
                  </div>

                  {authError && (
                    <p className="text-xs text-red-600 font-bold bg-red-50 p-2.5 rounded-xl border border-red-100 flex items-center space-x-2">
                      <span>⚠️</span>
                      <span>{authError}</span>
                    </p>
                  )}

                  <button 
                    type="submit"
                    className="w-full py-3.5 bg-blue-600 text-white font-extrabold text-xs uppercase rounded-xl tracking-wider hover:bg-blue-750 hover:-translate-y-0.5 active:translate-y-0 shadow-md hover:shadow-lg transition duration-200"
                  >
                    {isRegistering ? 'Register & Join' : 'Authenticate Credentials'}
                  </button>
                </form>

                {/* Social Google Divider & Login button */}
                <div className="relative flex py-3 items-center">
                  <div className="flex-grow border-t border-slate-100"></div>
                  <span className="flex-shrink mx-4 text-[9px] text-slate-400 font-black uppercase font-mono tracking-widest">or continue with</span>
                  <div className="flex-grow border-t border-slate-100"></div>
                </div>

                <button 
                  type="button"
                  onClick={handleGoogleLogin}
                  className="w-full py-3 px-4 bg-white border border-slate-200/80 hover:bg-slate-50 text-slate-700 font-semibold text-xs rounded-xl flex items-center justify-center gap-2.5 transition active:translate-y-[1px] shadow-sm hover:shadow-md border-b-2"
                >
                  <svg className="w-4.5 h-4.5" viewBox="0 0 24 24">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285f4" />
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34a853" />
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" fill="#fbbc05" />
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#ea4335" />
                  </svg>
                  <span className="font-extrabold uppercase tracking-wide">Continue with Google</span>
                </button>

                <div className="mt-5 pt-4.5 border-t border-slate-100 text-center text-xs text-slate-500 font-medium">
                  {isRegistering ? (
                    <p>
                      Already registered?{' '}
                      <button onClick={() => { setIsRegistering(false); setAuthError(''); }} className="text-blue-600 font-bold hover:underline">
                        Log In
                      </button>
                    </p>
                  ) : (
                    <p>
                      New aspirant around here?{' '}
                      <button onClick={() => { setIsRegistering(true); setAuthError(''); }} className="text-blue-600 font-bold hover:underline">
                        Create free account
                      </button>
                    </p>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Footer copyright */}
      <footer className="bg-[#0F172A] text-slate-400 text-xs py-8 mt-12 border-t border-slate-800" id="official-footer">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <p className="text-sm font-black tracking-widest text-slate-200 uppercase">
            ExamDuniya
          </p>
          <p className="text-[11px] text-slate-500 font-bold mt-2">
            © 2026 ExamDuniya • All Rights Reserved
          </p>
        </div>
      </footer>

    </div>
  );
}
