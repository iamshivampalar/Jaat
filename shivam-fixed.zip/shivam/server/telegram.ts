import { db } from './db';
import { JobNotification } from '../src/types';

// Safely escape characters that would break XML/HTML parsing in telegram
function escapeHTML(str: string): string {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

// Convert elementary markdown tags to HTML tags accepted by Telegram Bot HTML mode
function convertMarkdownToTelegramHTML(content: string): string {
  if (!content) return '';
  
  // Split into lines
  const lines = content.split('\n');
  const formattedLines = lines.map(line => {
    let trimmed = line.trim();
    if (!trimmed) return '';

    // Convert Headers to Bold: e.g. ### Header -> <b>Header</b>
    if (trimmed.startsWith('#')) {
      const headerText = trimmed.replace(/^#+\s*/, '');
      return `<b>${escapeHTML(headerText)}</b>`;
    }

    // Convert bullet points: e.g. - item -> • item
    if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
      const bulletText = trimmed.substring(2);
      return `• ${formatInlineMarkdown(bulletText)}`;
    }

    return formatInlineMarkdown(trimmed);
  });

  return formattedLines.filter(l => l !== null).join('\n');
}

// Format inline bold/italic markdown
function formatInlineMarkdown(text: string): string {
  let escaped = escapeHTML(text);
  
  // Replace **bold** with <b>bold</b>
  escaped = escaped.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>');
  
  // Replace *italic* or _italic_ with <i>italic</i>
  escaped = escaped.replace(/\*(.*?)\*/g, '<i>$1</i>');
  escaped = escaped.replace(/_(.*?)_/g, '<i>$1</i>');

  return escaped;
}

/**
 * Dispatches a beautifully formatted raw HTML message to the configured Telegram bot.
 */
export async function sendTelegramMessage(htmlText: string): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    db.log('info', `Telegram Auto-Posting is not configured. Message simulation: \n${htmlText}`);
    return false;
  }

  const url = `https://api.telegram.org/bot${token}/sendMessage`;

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: htmlText,
        parse_mode: 'HTML',
        disable_web_page_preview: false
      })
    });

    const data = await response.json().catch(() => ({}));
    if (response.ok && data.ok) {
      db.log('info', `Telegram Auto-Post: Successfully posted broadcast notification to Group/Channel [${chatId}]`);
      return true;
    } else {
      db.log('error', `Telegram Auto-Post Failed: ${data.description || 'Unknown Telegram API response error'}`);
      console.error('Telegram API rejected posting payload:', data);
      return false;
    }
  } catch (error: any) {
    db.log('error', `Telegram Auto-Post Exception: ${error.message}`);
    console.error('Failed to communicate with Telegram API Gateway:', error);
    return false;
  }
}

/**
 * Automate posting generated or manual Current Affairs briefing.
 */
export async function postCurrentAffairsToTelegram(ca: { title: string; content: string; category: string; tags?: string[] }) {
  const appUrl = process.env.APP_URL || 'https://examduniya.in';
  const currentDate = new Date().toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const parsedHeaderTitle = ca.title.replace(/^Important:\s*/i, '').replace(/^AI Special Briefing:\s*/i, '');
  const bodyHTML = convertMarkdownToTelegramHTML(ca.content);
  const tagString = (ca.tags || []).map(t => `#${t.replace(/\s+/g, '')}`).join(' ') || `#${ca.category}`;

  const message = `📰 <b>DAILY CURRENT AFFAIRS | EXAM DUNIYA</b>
━━━━━━━━━━━━━━━━━━━━━
🔑 <b>Topic:</b> ${escapeHTML(parsedHeaderTitle)}
📂 <b>Category:</b> ${escapeHTML(ca.category)}
⏱ <b>Date:</b> ${currentDate}

📝 <b>Briefing & Study Notes:</b>
${bodyHTML}

🏷 <b>Tags:</b> ${tagString}
━━━━━━━━━━━━━━━━━━━━━
🎓 <i>Excel in your IAS, SSC & State level exam preparation!</i>
🔗 <a href="${appUrl}">Open ExamDuniya Portal</a>`;

  return await sendTelegramMessage(message);
}

/**
 * Automate posting new Government Jobs / Recruitments.
 */
export async function postJobAlertToTelegram(job: JobNotification) {
  const appUrl = process.env.APP_URL || 'https://examduniya.in';
  
  const formattedDesc = convertMarkdownToTelegramHTML(job.details);
  const eligibility = job.qualification || 'Refer to official Notification';
  const ageLimit = job.ageLimit || 'As per government guidelines';
  const lastDate = job.lastDateToApply || 'N/A';
  const primaryLink = job.applyUrl || appUrl;
  const vacancyPosts = job.postCount ? `${job.postCount} Vacancies` : 'Not Specified';

  const message = `🔔 <b>NEW GOVT JOB NOTIFICATION | EXAM DUNIYA</b>
━━━━━━━━━━━━━━━━━━━━━
💼 <b>Post/Role:</b> ${escapeHTML(job.title)}
🏢 <b>Department:</b> ${escapeHTML(job.department)}
📂 <b>Category:</b> ${escapeHTML(job.category)}

🎯 <b>Total Openings:</b> ${escapeHTML(vacancyPosts)}
🎓 <b>Eligibility:</b> ${escapeHTML(eligibility)}
🔞 <b>Age Limit:</b> ${escapeHTML(ageLimit)}
📅 <b>Last Date:</b> ${escapeHTML(lastDate)}

📖 <b>Recruitment Details:</b>
${formattedDesc}

━━━━━━━━━━━━━━━━━━━━━
⚡ <i>Check full updates, download official PDFs, and practice custom AI Mock tests!</i>
🔗 <a href="${primaryLink}">Apply via ExamDuniya</a>`;

  return await sendTelegramMessage(message);
}
