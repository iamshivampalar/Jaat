import nodemailer from 'nodemailer';
import { db } from './db';

interface SMTPConfig {
  host: string;
  port: number;
  secure: boolean;
  user: string;
  pass: string;
  fromEmail: string;
  fromName: string;
}

// Lazy dynamic loader of SMTP configurations from environment
function getSMTPConfig(): SMTPConfig | null {
  const host = process.env.SMTP_HOST || '';
  const portStr = process.env.SMTP_PORT || '465';
  const secureStr = process.env.SMTP_SECURE || 'true';
  const user = process.env.SMTP_USER || '';
  const pass = process.env.SMTP_PASSWORD || '';
  const fromEmail = process.env.SMTP_FROM_EMAIL || '';
  const fromName = process.env.SMTP_FROM_NAME || 'ExamDuniya';

  if (!host || !user || !pass) {
    return null;
  }

  return {
    host,
    port: parseInt(portStr, 10) || 465,
    secure: secureStr === 'true',
    user,
    pass,
    fromEmail,
    fromName
  };
}

/**
 * Sends a premium password reset verification OTP HTML email.
 */
export async function sendOTPResetEmail(email: string, name: string, code: string): Promise<boolean> {
  const config = getSMTPConfig();

  if (!config) {
    db.log('info', `SMTP Mailer is not configured. Falling back to local console simulator. OTP Code for ${email} is: ${code}`);
    return false;
  }

  const transporter = nodemailer.createTransport({
    host: config.host,
    port: config.port,
    secure: config.secure,
    auth: {
      user: config.user,
      pass: config.pass
    },
    tls: {
      // Allow self-signed certs which are quite common on cPanel hostings
      rejectUnauthorized: false
    }
  });

  const subject = `[ExamDuniya] Security Alert: Password Reset Verification OTP (${code})`;
  const htmlContent = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f3f4f6; color: #1f2937; padding: 20px; }
        .card { max-width: 550px; margin: 0 auto; background-color: #ffffff; border-radius: 16px; border: 1px solid #e5e7eb; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .header { background-color: #222831; padding: 25px; text-align: center; border-bottom: 2px solid #71EEE2; }
        .header h1 { margin: 0; color: #71EEE2; font-size: 24px; text-transform: uppercase; letter-spacing: 1px; }
        .content { padding: 30px; line-height: 1.6; }
        .username { font-weight: bold; color: #111827; }
        .otp-box { background-color: #f9fafb; border: 2px dashed #71EEE2; color: #222831; font-size: 32px; font-weight: 800; text-align: center; letter-spacing: 6px; padding: 15px; margin: 25px 0; border-radius: 12px; font-family: monospace; }
        .footer { background-color: #f9fafb; padding: 20px; text-align: center; font-size: 11px; color: #9ca3af; border-top: 1px solid #f3f4f6; }
        .warning-text { font-size: 12px; color: #6b7280; border-left: 3px solid #ff9800; padding-left: 10px; margin-top: 20px; }
      </style>
    </head>
    <body>
      <div class="card">
        <div class="header">
          <h1>ExamDuniya</h1>
        </div>
        <div class="content">
          <p>Dear <span class="username">${name}</span>,</p>
          <p>A request has been made to verify your identity and reset your ExamDuniya passphrase lock. Please use the following 6-digit confirmation OTP code:</p>
          
          <div class="otp-box">${code}</div>
          
          <p>This verification token is confidential and valid only for next 10 minutes. Please enter it on the forgot password modal screen to proceed with credential updating.</p>
          
          <p class="warning-text"><strong>Security Alert:</strong> If you did not request this update, please ignore this email. Your credentials will remain unchanged and fully secured.</p>
        </div>
        <div class="footer">
          <p>This is an automated notification. Please do not reply directly to this mail.</p>
          <p>&copy; 2026 ExamDuniya. India's Smartest Exam Platform.</p>
        </div>
      </div>
    </body>
    </html>
  `;

  try {
    const info = await transporter.sendMail({
      from: `"${config.fromName}" <${config.fromEmail}>`,
      to: email,
      subject,
      html: htmlContent,
      text: `Hello ${name},\n\nYour 6-digit password reset verification OTP is: ${code}\n\nThis OTP is valid for 10 minutes.\n\nDisclaimer: If you did not initiate this request, please ignore this core email.\n\nRegards,\nTeam ExamDuniya`
    });

    db.log('info', `SMTP: Successful SMTP OTP dispatch to candidate: ${email} (Message ID: ${info.messageId})`);
    return true;
  } catch (error: any) {
    db.log('error', `SMTP Failure: Failed sending OTP register email to ${email}. SMTP Error details: ${error.message}`);
    console.error('SMTP Mail Transport Exception:', error);
    return false;
  }
}
